#include <stdio.h>
#include "batalla.h"
#include "perfil.h"
#include <time.h>
#include <stdlib.h> 
void validar_respuesta_crear(char* rta){
	while((*rta) != 'S' && (*rta) != 's' && (*rta) !='N' && (*rta) !='n'){
		printf("ERROR. No es una respuesta valida. Si quiere crear un personaje insgre 'S' o 's'\nEn caso contrario ingrese 'N' o 'n'.\n");
		scanf(" %c", rta);
	}
}
void cargar_mapa_inicial(char terreno[MAX_TERRENO_FIL][MAX_TERRENO_COL]){
	for(int fila = PRIMER_FILA; fila<MAX_TERRENO_FIL; fila++){
		for(int columna = PRIMER_COLUMNA; columna<MAX_TERRENO_COL; columna++){
			terreno[fila][columna] = TERRENO_VACIO;
		}
	}
}
void cargar_personajes(juego_t* juego){
	for(int i=0; i< juego->cantidad_isengard; i++){
			juego->terreno[juego->isengard[i].fila][juego->isengard[i].columna]=juego->isengard[i].codigo;
	}
	for(int r=0; r<juego->cantidad_rohan; r++){
			juego->terreno[juego->rohan[r].fila][juego->rohan[r].columna]=juego->rohan[r].codigo;
	}
}
void actualizar_terreno(juego_t* juego){
	for(int fila = PRIMER_FILA; fila < MAX_TERRENO_FIL; fila++){
		for(int col = PRIMER_COLUMNA; col<MAX_TERRENO_COL; col++){
			printf(" %c\t",juego->terreno[fila][col]);
		}
		printf("\n");
	}
	printf("\n");
}
void plus(jugador_t jugador, juego_t* juego){
	if(jugador.tipo == ROHAN){
		juego->plus_rohan = jugador.intensidad * (rand()%RANGO_PLUS);
	}else{
		juego->plus_isengard = jugador.intensidad * (rand()%RANGO_PLUS);
	}
}
void inicializar_personajes_fijos(personaje_t* personaje, int plus){
		personaje->vida = VIDA_ELFO_URUK - plus;
		personaje->ataque = ATAQUE_ELFO_URUK + plus;
		personaje->pts_energia = PTS_ELFO_URUK;
}
void inicializar_personajes_movibles(personaje_t* personaje, int plus){
		personaje->vida = VIDA_HOMBRE_ORCO - plus;
		personaje->ataque = ATAQUE_HOMBRE_ORCO + plus;
		personaje->pts_energia = PTS_HOMBRE_ORCO;
}
void posicionar_fijo_aleatorio( int* cantidad, personaje_t personaje, char terreno[MAX_TERRENO_FIL][MAX_TERRENO_COL], personaje_t vec_personajes[MAX_PERSONAJES], int amplitud){
	int fil_rndm;
	int col_rndm;
		for(; (*cantidad)<PERSONAJES_INICIALES; (*cantidad)++){
			fil_rndm = (rand()%4)+amplitud;
			col_rndm = rand()%10;
			for(int i=0; i<(*cantidad); i++){
				while(vec_personajes[i].fila == fil_rndm && vec_personajes[i].columna == col_rndm){
					fil_rndm = (rand()%4)+amplitud;
					col_rndm = rand()%10;
				}
			}
			vec_personajes[(*cantidad)].codigo = personaje.codigo;
			vec_personajes[(*cantidad)].vida = personaje.vida;
			vec_personajes[(*cantidad)].ataque = personaje.ataque;
			vec_personajes[(*cantidad)].fila = fil_rndm;
			vec_personajes[(*cantidad)].columna = col_rndm;
			vec_personajes[(*cantidad)].pts_energia = personaje.pts_energia;
		}
}
void posicionar_movil_aleatorio( int* cantidad, personaje_t personaje, char terreno[MAX_TERRENO_FIL][MAX_TERRENO_COL], personaje_t vec_personajes[MAX_PERSONAJES], jugador_t* jugador, int fila){
	int col_rndm;
	col_rndm = rand()%10;
	while((terreno[fila][col_rndm])!=TERRENO_VACIO){
		col_rndm = rand()%10;
	}
	vec_personajes[(*cantidad)].codigo = personaje.codigo;
	vec_personajes[(*cantidad)].vida = personaje.vida;
	vec_personajes[(*cantidad)].ataque = personaje.ataque;
	vec_personajes[(*cantidad)].fila = fila;
	vec_personajes[(*cantidad)].columna = col_rndm;
	vec_personajes[(*cantidad)].pts_energia = personaje.pts_energia;
	(*cantidad)++;
	(*jugador).energia -= personaje.pts_energia;
}
void posicionar_hombre(juego_t* juego, personaje_t personaje){
	printf("Elija una columna (del 0 al 9) de la ultima fila donde quiera posicionar al Hombre.\n");
	scanf("%i", &(juego->col_rohan));
	while((juego->col_rohan>ULTIMA_COLUMNA) || (juego->col_rohan)<PRIMER_COLUMNA){
		printf("ERROR: el numero no es valido.\nElija una columna (del 0 al 9) de la ultima fila donde quiera posicionar al hombre.\n");
		scanf("%i", &(juego->col_rohan));
	}
	while(juego->terreno[ULTIMA_FILA][juego->col_rohan]!= TERRENO_VACIO){
		printf("ERROR: Ese espacio esta ocupado.\nElija una columna (del 0 al 9) de la ultima fila donde quiera posicionar al hombre.\n");
		scanf("%i", &(juego->col_rohan));
	}
	juego->rohan[juego->cantidad_rohan] = personaje;
	juego->rohan[juego->cantidad_rohan].fila = ULTIMA_FILA;
	juego->rohan[juego->cantidad_rohan].columna = juego->col_rohan;
	juego->cantidad_rohan++;
	if(juego->j1.tipo == ROHAN){
		juego->j1.energia -= personaje.pts_energia;
	}else{
		juego->j2.energia -= personaje.pts_energia;
	}
}
void posicionar_orco(juego_t* juego, personaje_t personaje){
	printf("Elija una columna (del 0 al 9) de la primer fila donde quiera posicionar al Orco.\n");
	scanf("%i", &(juego->col_isengard));
	while((juego->col_isengard>ULTIMA_COLUMNA) || (juego->col_isengard)<PRIMER_COLUMNA){
		printf("ERROR: el numero no es valido.\nElija una columna (del 0 al 9) de la primer fila donde quiera posicionar al Orco.\n");
		scanf("%i", &(juego->col_isengard));
	}
	while(juego->terreno[PRIMER_FILA][juego->col_isengard]!= TERRENO_VACIO){
		printf("ERROR: Ese espacio esta ocupado.\nElija una columna (del 0 al 9) de la primer fila donde quiera posicionar al Orco.\n");
		scanf("%i", &(juego->col_isengard));
	}
	juego->isengard[juego->cantidad_isengard] = personaje;
	juego->isengard[juego->cantidad_isengard].fila = PRIMER_FILA;
	juego->isengard[juego->cantidad_isengard].columna = juego->col_isengard;
	(juego->cantidad_isengard)++;
	if(juego->j1.tipo == ISENGARD){
		juego->j1.energia -= personaje.pts_energia;
	}else{
		juego->j2.energia -= personaje.pts_energia;
	}
}
void posicionar_elfo(juego_t* juego, personaje_t personaje){
	printf("Elija una fila de su mitad de terreno donde quiera ubicar a su Elfo.\n");
	scanf("%i", &(juego->fila_rohan));
	while((juego->fila_rohan<((ULTIMA_FILA/2)+1)) || (juego->fila_rohan)>(ULTIMA_FILA-1)){
		printf("ERROR: el numero no es valido.\nElija una fila (del 5 al 8) donde quiera posicionar al Elfo.\n");
		scanf("%i", &(juego->fila_rohan));
	}
	printf("Elija una columna donde quiera ubicar a su Elfo.\n");
	scanf("%i", &(juego->col_rohan));
	while((juego->col_rohan < PRIMER_COLUMNA) || (juego->col_rohan) > ULTIMA_COLUMNA){
		printf("ERROR: el numero no es valido.\nElija una columna (del 0 al 9) donde quiera posicionar al Elfo.\n");
		scanf("%i", &(juego->col_rohan));
	}
	while(juego->terreno[juego->fila_rohan][juego->col_rohan]!= TERRENO_VACIO){
		printf("ERROR: Ese espacio esta ocupado.\nElija una fila (del 5 al 8) donde quiera posicionar al Elfo.\n");
		scanf("%i", &(juego->fila_rohan));
		while((juego->fila_rohan<((ULTIMA_FILA/2)+1)) || (juego->fila_rohan)>(ULTIMA_FILA-1)){
			printf("ERROR: el numero no es valido.\nElija una fila (del 5 al 8) donde quiera posicionar al Elfo.\n");
			scanf("%i", &(juego->fila_rohan));
		}
		printf("ERROR: Ese espacio esta ocupado.\nElija una columna (del 0 al 9) donde quiera posicionar al Elfo.\n");
		scanf("%i", &(juego->col_rohan));
		while((juego->col_rohan < PRIMER_COLUMNA) || (juego->col_rohan) > ULTIMA_COLUMNA){
			printf("ERROR: el numero no es valido.\nElija una columna (del 0 al 9) donde quiera posicionar al Elfo.\n");
			scanf("%i", &(juego->col_rohan));
		}
	}
	juego->rohan[juego->cantidad_rohan].codigo = ELFO;
	juego->rohan[juego->cantidad_rohan].vida = personaje.vida;
	juego->rohan[juego->cantidad_rohan].ataque = personaje.ataque;
	juego->rohan[juego->cantidad_rohan].fila = juego->fila_rohan;
	juego->rohan[juego->cantidad_rohan].columna = juego->col_rohan;
	juego->rohan[juego->cantidad_rohan].pts_energia = PTS_ELFO_URUK;
	(juego->cantidad_rohan)++;
	if(juego->j1.tipo == ROHAN){
		juego->j1.energia -= personaje.pts_energia;
	}else{
		juego->j2.energia -= personaje.pts_energia;
	}
}
void posicionar_uruk(juego_t* juego, personaje_t personaje){
	printf("Elija una fila de su mitad de terreno donde quiera ubicar a su Uruk-Hai.\n");
	scanf("%i", &(juego->fila_isengard));
	while((juego->fila_isengard<(PRIMER_FILA+1)) || (juego->fila_isengard)>(ULTIMA_FILA/2)){
		printf("ERROR: el numero no es valido.\nElija una fila (del 1 al 4) donde quiera posicionar al Uruk-Hai.\n");
		scanf("%i", &(juego->fila_isengard));
	}
	printf("Elija una columna donde quiera ubicar a su Uruk-Hai.\n");
	scanf("%i", &(juego->col_isengard));
	while((juego->col_isengard < PRIMER_COLUMNA) || (juego->col_isengard) > ULTIMA_COLUMNA){
		printf("ERROR: el numero no es valido.\nElija una columna (del 0 al 9) donde quiera posicionar al Uruk-Hai.\n");
		scanf("%i", &(juego->col_isengard));
	}
	while(juego->terreno[juego->fila_isengard][juego->col_isengard]!= TERRENO_VACIO){
		printf("ERROR: Ese espacio esta ocupado.\nElija una fila (del 1 al 4) donde quiera posicionar al Uruk-Hai.\n");
		scanf("%i", &(juego->fila_isengard));
		while((juego->fila_isengard < (PRIMER_FILA+1)) || (juego->fila_isengard) > (ULTIMA_FILA/2)){
			printf("ERROR: el numero no es valido.\nElija una fila (del 1 al 4) donde quiera posicionar al Uruk-Hai.\n");
			scanf("%i", &(juego->fila_isengard));
		}
		printf("ERROR: Ese espacio esta ocupado.\nElija una columna (del 0 al 9) donde quiera posicionar al Uruk-Hai.\n");
		scanf("%i", &(juego->col_isengard));
		while((juego->col_isengard < PRIMER_COLUMNA) || (juego->col_isengard) > ULTIMA_COLUMNA){
			printf("ERROR: el numero no es valido.\nElija una columna (del 0 al 9) donde quiera posicionar al Uruk-Hai.\n");
			scanf("%i", &(juego->col_isengard));
		}
	}
	juego->isengard[juego->cantidad_isengard].codigo = URUK;
	juego->isengard[juego->cantidad_isengard].vida = personaje.vida;
	juego->isengard[juego->cantidad_isengard].ataque = personaje.ataque;
	juego->isengard[juego->cantidad_isengard].fila = juego->fila_isengard;
	juego->isengard[juego->cantidad_isengard].columna = juego->col_isengard;
	juego->isengard[juego->cantidad_isengard].pts_energia = PTS_ELFO_URUK;
	(juego->cantidad_isengard)++;
	if(juego->j1.tipo == ISENGARD){
		juego->j1.energia -= personaje.pts_energia;
	}else{
		juego->j2.energia -= personaje.pts_energia;
	}
}
void personaje_murio(personaje_t personaje[MAX_PERSONAJES], int i, int* cantidad){
	if(personaje[i].vida == 0){
		for(int j=i+1; j<(*cantidad); j++){
			personaje[i] = personaje[j];	
		}
		(*cantidad)--;
	}
}
void personaje_llego(int* cantidad, personaje_t personaje[MAX_PERSONAJES], int* llegadas, int i){
	if(personaje[i].codigo == HOMBRE && personaje[i].fila == PRIMER_FILA && personaje[i].vida > 0){
			(*llegadas)++;
			for(int j=i+1; j<(*cantidad); j++){
				personaje[i] = personaje[j];	
			}
			(*cantidad)--;
		}else if(personaje[i].codigo == ORCO && personaje[i].fila == ULTIMA_FILA && personaje[i].vida > 0){
			(*llegadas)++;
			for(int j=i+1; j<(*cantidad); j++){
				personaje[i] = personaje[j];	
			}
			(*cantidad)--;
		}
}
void eliminar_personaje(int* cantidad, personaje_t personaje[MAX_PERSONAJES], int* llegadas){
	for(int i=0; i<(*cantidad); i++){
		personaje_murio(personaje, i, cantidad);
		personaje_llego( cantidad, personaje, llegadas, i);
	}		
}
void movimiento_personajes(int* cantidad_personajes, personaje_t personaje[MAX_PERSONAJES] , char bando, int posicion_personaje, int* llegadas, char terreno[MAX_TERRENO_FIL][MAX_TERRENO_COL], int movimiento, int fila_llegada){
	for(int i=0; i<(*cantidad_personajes);i++){
		if(personaje[i].codigo == HOMBRE){	
			if(terreno[personaje[i].fila+movimiento][personaje[i].columna] == TERRENO_VACIO || terreno[personaje[i].fila+movimiento][personaje[i].columna] == ELFO){
				personaje[i].fila +=movimiento;
			}
		}else if(personaje[i].codigo == ORCO){	
			if(terreno[personaje[i].fila+movimiento][personaje[i].columna] == TERRENO_VACIO || terreno[personaje[i].fila+movimiento][personaje[i].columna] == URUK){
				personaje[i].fila +=movimiento;
			}
		}
	}
	for(int i=0; i<(*cantidad_personajes); i++){
		if(personaje[i].fila == fila_llegada){
			eliminar_personaje(cantidad_personajes, personaje, llegadas);
		}
	}
}
void inicializar_juego(juego_t* juego){
	juego->uruk.codigo = URUK;
	juego->elfos.codigo = ELFO; 
	juego->hombres.codigo = HOMBRE; 
	juego->orcos.codigo = ORCO;  
	juego->cantidad_isengard = 0;
	juego->cantidad_rohan = 0;
	juego->turno_rohan = true;
	juego->turno_isengard = true;
	juego->llegadas_rohan = 0;
	juego->llegadas_isengard = 0;
	srand((unsigned)time(NULL));
	
	cargar_mapa_inicial(juego->terreno);
	printf("Completar Datos para el JUGADOR 1.\n");	
	perfil(&(juego)->j1.tipo, &(juego)->j1.intensidad);
	if(juego->j1.tipo == ROHAN){
		juego->j2.tipo = ISENGARD;
	}else{
		juego->j2.tipo = ROHAN;
	}
	juego->j2.intensidad = INTENSIDAD_MAX - juego->j1.intensidad;
	
	plus(juego->j1, juego);
	plus(juego->j2, juego);
	
	juego->j1.energia = ENERGIA_INICIAL;
	juego->j2.energia = ENERGIA_INICIAL;
	
	
	printf("1-Jugador vs. CPU\n2-Jugador 1 vs. Jugador 2\n");
	scanf("%i",&(juego->cant_jugadores));
	
	system("clear");
	inicializar_personajes_fijos(&(juego)->elfos, juego->plus_rohan);
	inicializar_personajes_movibles(&(juego)->hombres, juego->plus_rohan);
	inicializar_personajes_fijos(&(juego)->uruk, juego->plus_isengard);
	inicializar_personajes_movibles(&(juego)->orcos, juego->plus_isengard);	
	posicionar_fijo_aleatorio(&(juego)->cantidad_isengard, juego->uruk, juego->terreno, juego->isengard, 1 );
	posicionar_fijo_aleatorio(&(juego)->cantidad_rohan, juego->elfos, juego->terreno, juego->rohan, 5);
}
void posicionar_personaje(juego_t* juego, personaje_t personaje){
	if(personaje.codigo == HOMBRE){
		posicionar_hombre(juego, juego->hombres);
	}
	if(personaje.codigo == ORCO){
		posicionar_orco(juego, juego->orcos);
	}
	if(personaje.codigo == ELFO){
		posicionar_elfo(juego, juego->elfos);
	}
	if(personaje.codigo == URUK){
		posicionar_uruk(juego, juego->uruk);
	}
}
void ataque_hombres(juego_t* juego){
	for(int i=0; i<juego->cantidad_rohan; i++){
		if(juego->rohan[i].codigo == HOMBRE && juego->rohan[i].vida > 0){
			for(int r=0; r<juego->cantidad_isengard;r++){
				if((abs(juego->rohan[i].fila - juego->isengard[r].fila) + abs(juego->rohan[i].columna - juego->isengard[r].columna))<=1 && juego->isengard[r].vida > 0){
					juego->isengard[r].vida-=juego->rohan[i].ataque;
					if(juego->isengard[r].vida<=0){
						juego->terreno[juego->isengard[r].fila][juego->isengard[r].columna]=TERRENO_VACIO;
						juego->isengard[r].vida = 0;
					}
				}else if((juego->rohan[i].fila)-1 == juego->isengard[r].fila && (juego->rohan[i].columna)-1 == juego->isengard[r].columna && ((juego->rohan[i].fila)-1 >= PRIMER_FILA) && ((juego->rohan[i].columna)-1 >= PRIMER_COLUMNA)){
					juego->isengard[r].vida-=juego->rohan[i].ataque;
					if(juego->isengard[r].vida<=0){
						juego->terreno[juego->isengard[r].fila][juego->isengard[r].columna]=TERRENO_VACIO;
						juego->isengard[r].vida = 0;
					}
				}else if((juego->rohan[i].fila)-1 == juego->isengard[r].fila && (juego->rohan[i].columna)+1 == juego->isengard[r].columna && ((juego->rohan[i].fila)-1 >= PRIMER_FILA) && ((juego->rohan[i].columna)+1 <= ULTIMA_COLUMNA)){
					juego->isengard[r].vida-=juego->rohan[i].ataque;
					if(juego->isengard[r].vida<=0){
						juego->terreno[juego->isengard[r].fila][juego->isengard[r].columna]=TERRENO_VACIO;
						juego->isengard[r].vida = 0;
					}
				}else if((juego->rohan[i].fila)+1 == juego->isengard[r].fila && (juego->rohan[i].columna)-1 == juego->isengard[r].columna && ((juego->rohan[i].fila)+1 <= ULTIMA_FILA) && ((juego->rohan[i].columna)-1 >= PRIMER_COLUMNA)){
					juego->isengard[r].vida-=juego->rohan[i].ataque;
					if(juego->isengard[r].vida<=0){
						juego->terreno[juego->isengard[r].fila][juego->isengard[r].columna]=TERRENO_VACIO;
						juego->isengard[r].vida = 0;
					}
				}else if((juego->rohan[i].fila)+1 == juego->isengard[r].fila && (juego->rohan[i].columna)+1 == juego->isengard[r].columna && ((juego->rohan[i].fila)+1 <= ULTIMA_FILA) && ((juego->rohan[i].columna)+1 <= ULTIMA_COLUMNA)){
					juego->isengard[r].vida-=juego->rohan[i].ataque;
					if(juego->isengard[r].vida<=0){
						juego->terreno[juego->isengard[r].fila][juego->isengard[r].columna]=TERRENO_VACIO;
						juego->isengard[r].vida = 0;
					}
				}
			}
		}	
	}

	for(int i=0; i<juego->cantidad_isengard; i++){
		if(juego->isengard[i].vida == 0){
			eliminar_personaje(&(juego)->cantidad_isengard, juego->isengard, &(juego)->llegadas_isengard);
		}
	}
}
void ataque_orcos(juego_t* juego){
	for(int i=0; i<juego->cantidad_isengard; i++){
		if(juego->isengard[i].codigo == ORCO && juego->isengard[i].vida > 0){
			for(int r=0; r<juego->cantidad_rohan;r++){
				if((abs(juego->isengard[i].fila - juego->rohan[r].fila) + abs(juego->isengard[i].columna - juego->rohan[r].columna))<=1 && juego->rohan[r].vida > 0){
					juego->rohan[r].vida-=juego->isengard[i].ataque;
					if(juego->rohan[r].vida<=0){
						juego->terreno[juego->rohan[r].fila][juego->rohan[r].columna]=TERRENO_VACIO;
						juego->rohan[r].vida = 0;
					}
				}else if((juego->isengard[i].fila)-1 == juego->rohan[r].fila && (juego->isengard[i].columna)-1 == juego->rohan[r].columna && ((juego->isengard[i].fila)-1 >= PRIMER_FILA) && ((juego->isengard[i].columna)-1 >= PRIMER_COLUMNA)){
					juego->rohan[r].vida-=juego->isengard[i].ataque;
					if(juego->rohan[r].vida<=0){
						juego->terreno[juego->rohan[r].fila][juego->rohan[r].columna]=TERRENO_VACIO;
						juego->rohan[r].vida = 0;
					}
				}else if((juego->isengard[i].fila)-1 == juego->rohan[r].fila && (juego->isengard[i].columna)+1 == juego->rohan[r].columna && ((juego->isengard[i].fila)-1 >= PRIMER_FILA) && ((juego->isengard[i].columna)+1 <= ULTIMA_COLUMNA)){
					juego->rohan[r].vida-=juego->isengard[i].ataque;
					if(juego->rohan[r].vida<=0){
						juego->terreno[juego->rohan[r].fila][juego->rohan[r].columna]=TERRENO_VACIO;
						juego->rohan[r].vida = 0;
					}
				}else if((juego->isengard[i].fila)+1 == juego->rohan[r].fila && (juego->isengard[i].columna)-1 == juego->rohan[r].columna && ((juego->isengard[i].fila)+1 <= ULTIMA_FILA) && ((juego->isengard[i].columna)-1 >= PRIMER_COLUMNA)){
					juego->rohan[r].vida-=juego->isengard[i].ataque;
					if(juego->rohan[r].vida<=0){
						juego->terreno[juego->rohan[r].fila][juego->rohan[r].columna]=TERRENO_VACIO;
						juego->rohan[r].vida = 0;
					}
				}else if((juego->isengard[i].fila)+1 == juego->rohan[r].fila && (juego->isengard[i].columna)+1 == juego->rohan[r].columna && ((juego->isengard[i].fila)+1 <= ULTIMA_FILA) && ((juego->isengard[i].columna)+1 <= ULTIMA_COLUMNA)){
					juego->rohan[r].vida-=juego->isengard[i].ataque;
					if(juego->rohan[r].vida<=0){
						juego->terreno[juego->rohan[r].fila][juego->rohan[r].columna]=TERRENO_VACIO;
						juego->rohan[r].vida = 0;
					}
				}
			}
		}	
	}
	for(int i=0; i<juego->cantidad_rohan; i++){
		if(juego->rohan[i].vida == 0){
			eliminar_personaje(&(juego)->cantidad_rohan, juego->rohan, &(juego)->llegadas_rohan);
		}
	}
}
void ataque_elfos(juego_t* juego){
	for(int i=0; i<juego->cantidad_rohan; i++){
		if(juego->rohan[i].codigo == ELFO && juego->rohan[i].vida > 0){
			for(int r=0; r<juego->cantidad_isengard;r++){
				if((abs(juego->rohan[i].fila - juego->isengard[r].fila)+ abs(juego->rohan[i].columna - juego->isengard[r].columna))<=3 && juego->isengard[r].vida > 0){
					juego->isengard[r].vida-=juego->rohan[i].ataque;
					if(juego->isengard[r].vida<=0){
						juego->isengard[r].vida = 0;
					}
				}
			}
		}
	}
	eliminar_personaje(&(juego)->cantidad_isengard, juego->isengard, &(juego)->llegadas_isengard);				
}
void ataque_uruk(juego_t* juego){
	for(int i=0; i<juego->cantidad_isengard; i++){
		if(juego->isengard[i].codigo == URUK && juego->isengard[i].vida > 0){
			for(int r=0; r<juego->cantidad_rohan;r++){
				if((abs(juego->isengard[i].fila - juego->rohan[r].fila) + abs(juego->isengard[i].columna - juego->rohan[r].columna))<= 3 && juego->rohan[r].vida > 0){
					juego->rohan[r].vida-=juego->isengard[i].ataque;
					if(juego->rohan[r].vida<=0){
						juego->terreno[juego->rohan[r].fila][juego->rohan[r].columna]=TERRENO_VACIO;
						juego->rohan[r].vida = 0;
					}
				}
			}
		}
	}
	eliminar_personaje(&(juego)->cantidad_rohan, juego->rohan, &(juego)->llegadas_rohan);
}
void jugar(juego_t* juego, char bando, int posicion_personaje){
	if(bando == ISENGARD){
		movimiento_personajes(&(juego)->cantidad_isengard, juego->isengard, ISENGARD, juego->isengard->fila, &(juego)->llegadas_isengard, juego->terreno, 1, ULTIMA_FILA);
		ataque_orcos(juego);
		ataque_uruk(juego);

	}else{
		movimiento_personajes(&(juego)->cantidad_rohan, juego->rohan, ROHAN, juego->rohan->fila, &(juego)->llegadas_rohan, juego->terreno, -1, PRIMER_FILA);
		ataque_hombres(juego);
		ataque_elfos(juego);
	}
}
void ganar(int llegadas, bool* juego_terminado, bool* turno_actual, bool* turno_enemigo, char bando[10]){
	if(llegadas == LLEGADAS_GANAR){
		(*juego_terminado) = true;
		(*turno_actual)=false;
		(*turno_enemigo) = false;
		system("clear");
		printf("\n%s Gana!!!\n", bando);
	}
}
void aumentar_energia(jugador_t* j1, jugador_t* j2){
	(*j1).energia++;
	(*j2).energia++;
	if((*j1).energia > ENERGIA_MAX){
		(*j1).energia = ENERGIA_MAX;
	}
	if((*j2).energia > ENERGIA_MAX){
		(*j2).energia = ENERGIA_MAX;
	}
}
void turno_roh(bool* turno_rohan, bool* turno_isengard, juego_t* juego, bool* juego_terminado, char nombre_rohan[10]){
	while((*turno_rohan)){
		system("clear");
		if(juego->j1.tipo == ROHAN){
			cargar_mapa_inicial(juego->terreno);
			cargar_personajes(juego);
			actualizar_terreno(juego);
			printf("Energia Rohan: %i\n", juego->j1.energia);
			printf("Llegadas Rohan: %i", juego->llegadas_rohan);
			printf("\n\t\tTURNO ROHAN.\nDesea crear un personaje?.(S/N).\n");
			scanf(" %c", &(*juego).rta_rohan);
			validar_respuesta_crear(&(*juego).rta_rohan);
			if(juego->rta_rohan == 'S' || juego->rta_rohan == 's'){
				printf("Que personaje desea crear?.\n1-Hombre.(3pts. de energia)\n2-Elfo.(8pts. de energia)\n");
				scanf("%i", &(*juego).crear_rohan);
				while(juego->crear_rohan !=1 && juego->crear_rohan !=2){
					printf("ERROR. Ingrese una opcion valida.\n1-Hombre.(3pts. de energia)\n2-Elfo.(8pts. de energia)\n");
					scanf("%i", &(*juego).crear_rohan);
				}
				if(juego->crear_rohan == 1){
					if(juego->j1.energia >= juego->hombres.pts_energia){
						posicionar_personaje(juego, juego->hombres);
					}else{
					printf("\nNo tiene puntos suficientes para crear a un Hombre.\n");
					}
				}else{
					if(juego->j1.energia >= juego->elfos.pts_energia){
						posicionar_personaje(juego, juego->elfos);
					}else{
						printf("\nNo tiene puntos suficientes para crear a un Elfo.\n");
					}
				}
			}else{
				(*turno_rohan) = false;
				(*turno_isengard) = true;
			}
		}else if(juego->j2.tipo == ROHAN){
			cargar_mapa_inicial(juego->terreno);
			cargar_personajes(juego);
			actualizar_terreno(juego);
			printf("Energia Rohan: %i\n", juego->j2.energia);
			printf("Llegadas Rohan: %i", juego->llegadas_rohan);
			printf("\n\t\tTURNO ROHAN.\nDesea crear un personaje?.(S/N).\n");
			scanf(" %c", &(*juego).rta_rohan);
			validar_respuesta_crear(&(*juego).rta_rohan);
			if(juego->rta_rohan == 'S' || juego->rta_rohan == 's'){
				printf("Que personaje desea crear?.\n1-Hombre.(3pts. de energia)\n2-Elfo.(8pts. de energia)\n");
				scanf("%i", &(*juego).crear_rohan);
				while(juego->crear_rohan !=1 && juego->crear_rohan !=2){
					printf("ERROR. Ingrese una opcion valida.\n1-Hombre.(3pts. de energia)\n2-Elfo.(8pts. de energia)\n");
					scanf("%i", &(*juego).crear_rohan);
				}
				if(juego->crear_rohan == 1){
					if(juego->j2.energia >= juego->hombres.pts_energia){
						posicionar_personaje(juego, juego->hombres);
					}else{
						printf("No tiene puntos suficientes para crear a un Hombre.\n");
					}
				}else{
					if(juego->j2.energia >= juego->elfos.pts_energia){
						posicionar_personaje(juego, juego->elfos);
					}else{
						printf("No tiene puntos suficientes para crear a un Elfo.\n");
					}
				}
			}else{
				(*turno_rohan) = false;
				(*turno_isengard) = true;
			}
		}
	}
	jugar(juego, ROHAN, juego->rohan->fila);
	ganar(juego->llegadas_rohan, &(*juego_terminado), &(*turno_rohan), &(*turno_isengard), nombre_rohan);	
}
void turno_isen(bool* turno_rohan, bool* turno_isengard, juego_t* juego, bool* juego_terminado, char nombre_isengard[10]){
	while((*turno_isengard)){
		system("clear");
		if(juego->j1.tipo == ISENGARD){
			cargar_mapa_inicial(juego->terreno);
			cargar_personajes(juego);
			actualizar_terreno(juego);
			printf("Energia Isengard: %i\n", juego->j1.energia);
			printf("Llegadas Isengard: %i", juego->llegadas_isengard);
			printf("\n\t\tTURNO ISENGARD.\nDesea crear un personaje?.(S/N).\n");
			scanf(" %c", &(*juego).rta_isengard);
			if(juego->rta_isengard == 'S' || juego->rta_isengard == 's'){
				printf("Que personaje desea crear?.\n1-Orco.(3pts. de energia)\n2-Uruk-Hai.(8pts. de energia)\n");
				scanf("%i", &(*juego).crear_isengard);
				validar_respuesta_crear(&(*juego).rta_isengard);
				while(juego->crear_isengard !=1 && juego->crear_isengard !=2){
					printf("ERROR. Ingrese una opcion valida.\n1-Orco.(3pts. de energia)\n2-Uruk-Hai.(8pts. de energia)\n");
					scanf("%i", &(*juego).crear_isengard);
				}
				if(juego->crear_isengard == 1){
					if(juego->j1.energia >= juego->orcos.pts_energia){
						posicionar_personaje(juego, juego->orcos);
					}else{
						printf("No tiene puntos suficientes para crear a un Orco.\n");
					}
				}else{
					if(juego->j1.energia >= juego->uruk.pts_energia){
						posicionar_personaje(juego, juego->uruk);
					}else{
						printf("No tiene puntos suficientes para crear a un Uruk-Hai.\n");
					}
				}
			}else{
				(*turno_isengard) = false;
				(*turno_rohan) = true;
			}
		}else if(juego->j2.tipo == ISENGARD){
			cargar_mapa_inicial(juego->terreno);
			cargar_personajes(juego);
			actualizar_terreno(juego);
			printf("Energia Isengard: %i\n", juego->j2.energia);
			printf("Llegadas Isengard: %i", juego->llegadas_isengard);
			printf("\n\t\tTURNO ISENGARD.\nDesea crear un personaje?.(S/N).\n");
			scanf(" %c", &(*juego).rta_isengard);
			validar_respuesta_crear(&(*juego).rta_isengard);
			if(juego->rta_isengard == 'S' || juego->rta_isengard == 's'){
				printf("Que personaje desea crear?.\n1-Orco.(3pts. de energia)\n2-Uruk-Hai.(8pts. de energia)\n");
				scanf("%i", &(*juego).crear_isengard);
				while(juego->crear_isengard !=1 && juego->crear_isengard !=2){
					printf("ERROR. Ingrese una opcion valida.\n1-Orco.(3pts. de energia)\n2-Uruk-Hai.(8pts. de energia)\n");
					scanf("%i", &(*juego).crear_isengard);
				}
				if(juego->crear_isengard == 1){
					if(juego->j2.energia >= juego->orcos.pts_energia){
						posicionar_personaje(juego, juego->orcos);
					}else{
						printf("No tiene puntos suficientes para crear a un Orco.\n");
					}
				}else{
					if(juego->j2.energia >= juego->uruk.pts_energia){
						posicionar_personaje(juego, juego->uruk);
					}else{
						printf("No tiene puntos suficientes para crear a un Uruk-Hai.\n");
					}
				}
			}else{
				(*turno_isengard) = false;
				(*turno_rohan) = true;
			}		
		}	
	}
	jugar(juego, ISENGARD, juego->isengard->fila);
	ganar(juego->llegadas_isengard, &(*juego_terminado), &(*turno_isengard), &(*turno_rohan), nombre_isengard);
}