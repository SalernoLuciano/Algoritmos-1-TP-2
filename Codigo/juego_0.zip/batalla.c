#include <stdio.h>
#include "batalla.h"
#include "perfil.h"
#include <time.h>
#include <stdlib.h> 

void cargar_mapa_inicial(char terreno[MAX_TERRENO_FIL][MAX_TERRENO_COL]){
	for(int fila = PRIMER_FILA; fila<MAX_TERRENO_FIL; fila++){
		for(int columna = PRIMER_COLUMNA; columna<MAX_TERRENO_COL; columna++){
			terreno[fila][columna] = TERRENO_VACIO;
		}
	}
}
void plus(jugador_t jugador, juego_t* juego){
	if(jugador.tipo == ROHAN){
		juego->plus_rohan = jugador.intensidad * (rand()%RANGO_PLUS);
	}else{
		juego->plus_isengard = jugador.intensidad * (rand()%RANGO_PLUS);
	}
}
void inicializar_personajes_fijos(personaje_t* personaje, juego_t* juego){
	if(personaje->codigo == URUK){
		personaje->vida = VIDA_ELFO_URUK - juego->plus_isengard;
		personaje->ataque = ATAQUE_ELFO_URUK + juego->plus_isengard;
		personaje->pts_energia = PTS_ELFO_URUK;
	}else{
		personaje->vida = VIDA_ELFO_URUK - juego->plus_rohan;
		personaje->ataque = ATAQUE_ELFO_URUK + juego->plus_rohan;
		personaje->pts_energia = PTS_ELFO_URUK;
	}
}
void inicializar_personajes_movibles(personaje_t* personaje, juego_t* juego){
	if(personaje->codigo == ORCO){
		personaje->vida = VIDA_HOMBRE_ORCO - juego->plus_isengard;
		personaje->ataque = ATAQUE_HOMBRE_ORCO + juego->plus_isengard;
		personaje->pts_energia = PTS_HOMBRE_ORCO;
	}else{
		personaje->vida = VIDA_HOMBRE_ORCO - juego->plus_rohan;
		personaje->ataque = ATAQUE_HOMBRE_ORCO + juego->plus_rohan;
		personaje->pts_energia = PTS_HOMBRE_ORCO;
	}
}
void posicionar_uruk_aleatorio( juego_t* juego, personaje_t uruk){
	int fil_rndm;
	int col_rndm;
		for(; (juego->cantidad_isengard)<PERSONAJES_INICIALES; (juego->cantidad_isengard)++){
			fil_rndm = (rand()%4)+1;
			col_rndm = rand()%10;
			while((juego->terreno[fil_rndm][col_rndm])!=TERRENO_VACIO){
				fil_rndm = (rand()%4)+1;
				col_rndm = rand()%10;
			}
			juego->terreno[fil_rndm][col_rndm] = URUK;
			juego->isengard[(juego->cantidad_isengard)].codigo = uruk.codigo;
			juego->isengard[(juego->cantidad_isengard)].vida = uruk.vida;
			juego->isengard[(juego->cantidad_isengard)].ataque = uruk.ataque;
			juego->isengard[(juego->cantidad_isengard)].fila = fil_rndm;
			juego->isengard[(juego->cantidad_isengard)].columna = col_rndm;
			juego->isengard[(juego->cantidad_isengard)].pts_energia = uruk.pts_energia;
		}
}
void posicionar_elfo_aleatorio( juego_t* juego, personaje_t elfos){
	int fil_rndm;
	int col_rndm;
		for(; (juego->cantidad_rohan)<PERSONAJES_INICIALES; (juego->cantidad_rohan)++){
			fil_rndm = (rand()%4)+5;
			col_rndm = rand()%10;
			while((juego->terreno[fil_rndm][col_rndm])!=TERRENO_VACIO){
				fil_rndm = (rand()%4)+5;
				col_rndm = rand()%10;
			}
			juego->terreno[fil_rndm][col_rndm] = ELFO;
			juego->rohan[(juego->cantidad_rohan)].codigo = elfos.codigo;
			juego->rohan[(juego->cantidad_rohan)].vida = elfos.vida;
			juego->rohan[(juego->cantidad_rohan)].ataque = elfos.ataque;
			juego->rohan[(juego->cantidad_rohan)].fila = fil_rndm;
			juego->rohan[(juego->cantidad_rohan)].columna = col_rndm;
			juego->rohan[(juego->cantidad_rohan)].pts_energia = elfos.pts_energia;
		}
}
void actualizar_terreno(char terreno[MAX_TERRENO_FIL][MAX_TERRENO_COL]){
	for(int fila = PRIMER_FILA; fila<MAX_TERRENO_FIL; fila++){
		for(int columna = PRIMER_COLUMNA; columna<MAX_TERRENO_COL; columna++){
			printf(" %c\t", terreno[fila][columna]);
		}
		printf("\n");
	}
	printf("\n");
}
void posicionar_hombre(juego_t* juego, personaje_t personaje){
	printf("Elija una columna (del 0 al 9) de la ultima fila donde quiera posicionar al Hombre.\n");
	scanf("%i", &(juego->col_rohan));
	while((juego->col_rohan>ULTIMA_COLUMNA) || (juego->col_rohan)<PRIMER_COLUMNA){
		printf("ERROR: el numero no es valido.\nElija una columna (del 0 al 9) de la ultima fila donde quiera posicionar al hombre.\n");
		scanf("%i", &(juego->col_rohan));
	}
	while(juego->terreno[ULTIMA_FILA][juego->col_rohan]!= TERRENO_VACIO){
		printf("ERROR: Ese espacio esta ocupado.\nElija una columna (del 0 al 9) de la ultima fila donde quiera posicionar al hombre.\n");
		scanf("%i", &(juego->col_rohan));
	}
	juego->terreno[ULTIMA_FILA][juego->col_rohan] = HOMBRE;
	juego->rohan[juego->cantidad_rohan].codigo = HOMBRE;
	juego->rohan[juego->cantidad_rohan].vida = personaje.vida;
	juego->rohan[juego->cantidad_rohan].ataque = personaje.ataque;
	juego->rohan[juego->cantidad_rohan].fila = ULTIMA_FILA;
	juego->rohan[juego->cantidad_rohan].columna = juego->col_rohan;
	juego->rohan[juego->cantidad_rohan].pts_energia = PTS_HOMBRE_ORCO;
	(juego->cantidad_rohan)++;
	if(juego->j1.tipo == ROHAN){
		juego->j1.energia -= personaje.pts_energia;
	}else{
		juego->j2.energia -= personaje.pts_energia;
	}
}
void posicionar_orco(juego_t* juego, personaje_t personaje){
	printf("Elija una columna (del 0 al 9) de la primer fila donde quiera posicionar al Orco.\n");
	scanf("%i", &(juego->col_isengard));
	while((juego->col_isengard>ULTIMA_COLUMNA) || (juego->col_isengard)<PRIMER_COLUMNA){
		printf("ERROR: el numero no es valido.\nElija una columna (del 0 al 9) de la primer fila donde quiera posicionar al Orco.\n");
		scanf("%i", &(juego->col_isengard));
	}
	while(juego->terreno[PRIMER_FILA][juego->col_isengard]!= TERRENO_VACIO){
		printf("ERROR: Ese espacio esta ocupado.\nElija una columna (del 0 al 9) de la primer fila donde quiera posicionar al Orco.\n");
		scanf("%i", &(juego->col_isengard));
	}
	juego->terreno[PRIMER_FILA][juego->col_isengard] = ORCO;
	juego->isengard[juego->cantidad_isengard].codigo = ORCO;
	juego->isengard[juego->cantidad_isengard].vida = personaje.vida;
	juego->isengard[juego->cantidad_isengard].ataque = personaje.ataque;
	juego->isengard[juego->cantidad_isengard].fila = PRIMER_FILA;
	juego->isengard[juego->cantidad_isengard].columna = juego->col_isengard;
	juego->isengard[juego->cantidad_isengard].pts_energia = PTS_HOMBRE_ORCO;
	(juego->cantidad_isengard)++;
	if(juego->j1.tipo == ISENGARD){
		juego->j1.energia -= personaje.pts_energia;
	}else{
		juego->j2.energia -= personaje.pts_energia;
	}
}
void posicionar_elfo(juego_t* juego, personaje_t personaje){
	printf("Elija una fila de su mitad de terreno donde quiera ubicar a su Elfo.\n");
	scanf("%i", &(juego->fila_rohan));
	while((juego->fila_rohan<((ULTIMA_FILA/2)+1)) || (juego->fila_rohan)>(ULTIMA_FILA-1)){
		printf("ERROR: el numero no es valido.\nElija una fila (del 5 al 8) donde quiera posicionar al Elfo.\n");
		scanf("%i", &(juego->fila_rohan));
	}
	printf("Elija una columna donde quiera ubicar a su Elfo.\n");
	scanf("%i", &(juego->col_rohan));
	while((juego->col_rohan < PRIMER_COLUMNA) || (juego->col_rohan) > ULTIMA_COLUMNA){
		printf("ERROR: el numero no es valido.\nElija una columna (del 0 al 9) donde quiera posicionar al Elfo.\n");
		scanf("%i", &(juego->col_rohan));
	}
	while(juego->terreno[juego->fila_rohan][juego->col_rohan]!= TERRENO_VACIO){
		printf("ERROR: Ese espacio esta ocupado.\nElija una fila (del 5 al 8) donde quiera posicionar al Elfo.\n");
		scanf("%i", &(juego->fila_rohan));
		while((juego->fila_rohan<((ULTIMA_FILA/2)+1)) || (juego->fila_rohan)>(ULTIMA_FILA-1)){
			printf("ERROR: el numero no es valido.\nElija una fila (del 5 al 8) donde quiera posicionar al Elfo.\n");
			scanf("%i", &(juego->fila_rohan));
		}
		printf("ERROR: Ese espacio esta ocupado.\nElija una columna (del 0 al 9) donde quiera posicionar al Elfo.\n");
		scanf("%i", &(juego->col_rohan));
		while((juego->col_rohan < PRIMER_COLUMNA) || (juego->col_rohan) > ULTIMA_COLUMNA){
			printf("ERROR: el numero no es valido.\nElija una columna (del 0 al 9) donde quiera posicionar al Elfo.\n");
			scanf("%i", &(juego->col_rohan));
		}
	}
	juego->terreno[juego->fila_rohan][juego->col_rohan] = ELFO;
	juego->rohan[juego->cantidad_rohan].codigo = ELFO;
	juego->rohan[juego->cantidad_rohan].vida = personaje.vida;
	juego->rohan[juego->cantidad_rohan].ataque = personaje.ataque;
	juego->rohan[juego->cantidad_rohan].fila = juego->fila_rohan;
	juego->rohan[juego->cantidad_rohan].columna = juego->col_rohan;
	juego->rohan[juego->cantidad_rohan].pts_energia = PTS_ELFO_URUK;
	(juego->cantidad_rohan)++;
	if(juego->j1.tipo == ROHAN){
		juego->j1.energia -= personaje.pts_energia;
	}else{
		juego->j2.energia -= personaje.pts_energia;
	}
}
void posicionar_uruk(juego_t* juego, personaje_t personaje){
	printf("Elija una fila de su mitad de terreno donde quiera ubicar a su Uruk-Hai.\n");
	scanf("%i", &(juego->fila_isengard));
	while((juego->fila_isengard<(PRIMER_FILA+1)) || (juego->fila_isengard)>(ULTIMA_FILA/2)){
		printf("ERROR: el numero no es valido.\nElija una fila (del 1 al 4) donde quiera posicionar al Uruk-Hai.\n");
		scanf("%i", &(juego->fila_isengard));
	}
	printf("Elija una columna donde quiera ubicar a su Uruk-Hai.\n");
	scanf("%i", &(juego->col_isengard));
	while((juego->col_isengard < PRIMER_COLUMNA) || (juego->col_isengard) > ULTIMA_COLUMNA){
		printf("ERROR: el numero no es valido.\nElija una columna (del 0 al 9) donde quiera posicionar al Uruk-Hai.\n");
		scanf("%i", &(juego->col_isengard));
	}
	while(juego->terreno[juego->fila_isengard][juego->col_isengard]!= TERRENO_VACIO){
		printf("ERROR: Ese espacio esta ocupado.\nElija una fila (del 1 al 4) donde quiera posicionar al Uruk-Hai.\n");
		scanf("%i", &(juego->fila_isengard));
		while((juego->fila_isengard < (PRIMER_FILA+1)) || (juego->fila_isengard) > (ULTIMA_FILA/2)){
			printf("ERROR: el numero no es valido.\nElija una fila (del 1 al 4) donde quiera posicionar al Uruk-Hai.\n");
			scanf("%i", &(juego->fila_isengard));
		}
		printf("ERROR: Ese espacio esta ocupado.\nElija una columna (del 0 al 9) donde quiera posicionar al Uruk-Hai.\n");
		scanf("%i", &(juego->col_isengard));
		while((juego->col_isengard < PRIMER_COLUMNA) || (juego->col_isengard) > ULTIMA_COLUMNA){
			printf("ERROR: el numero no es valido.\nElija una columna (del 0 al 9) donde quiera posicionar al Uruk-Hai.\n");
			scanf("%i", &(juego->col_isengard));
		}
	}
	juego->terreno[juego->fila_isengard][juego->col_isengard] = URUK;
	juego->isengard[juego->cantidad_isengard].codigo = URUK;
	juego->isengard[juego->cantidad_isengard].vida = personaje.vida;
	juego->isengard[juego->cantidad_isengard].ataque = personaje.ataque;
	juego->isengard[juego->cantidad_isengard].fila = juego->fila_isengard;
	juego->isengard[juego->cantidad_isengard].columna = juego->col_isengard;
	juego->isengard[juego->cantidad_isengard].pts_energia = PTS_ELFO_URUK;
	(juego->cantidad_isengard)++;
	if(juego->j1.tipo == ISENGARD){
		juego->j1.energia -= personaje.pts_energia;
	}else{
		juego->j2.energia -= personaje.pts_energia;
	}
}
void movimiento_hombres(juego_t* juego, char bando, int posicion_personaje){
	for(int fila = PRIMER_FILA+1; fila<=ULTIMA_FILA; fila++){
		for(int col = PRIMER_COLUMNA; col <= ULTIMA_COLUMNA; col++){
			if(juego->terreno[fila][col] == HOMBRE){
				for(int i=0; i<juego->cantidad_rohan;i++){
					if(juego->rohan[i].codigo == HOMBRE && juego->rohan[i].fila == fila && juego->rohan[i].columna == col){
						while(juego->terreno[fila-1][col]== TERRENO_VACIO){
							juego->terreno[fila-1][col] = HOMBRE;
							juego->terreno[fila][col] = TERRENO_VACIO;
							juego->rohan[i].fila = fila-1;
						}
					}
					if(juego->terreno[PRIMER_FILA][col] == HOMBRE){
						juego->terreno[PRIMER_FILA][col] = TERRENO_VACIO;
						(juego->llegadas_rohan)++;
					}
				}
			}
		}
	}
}
void movimiento_orcos(juego_t* juego, char bando, int posicion_personaje){
	for(int fila = ULTIMA_FILA; fila >= PRIMER_FILA; fila--){
				for(int col = PRIMER_COLUMNA; col <= ULTIMA_COLUMNA; col++){
					if(juego->terreno[fila][col] == ORCO){
						for(int j=0; j<juego->cantidad_isengard; j++){
							if(juego->isengard[j].codigo == ORCO && juego->isengard[j].fila == fila){
								while(juego->terreno[fila+1][col]== TERRENO_VACIO || juego->terreno[fila+1][col] == URUK){
									juego->terreno[fila+1][col] = ORCO;
									juego->terreno[fila][col] = TERRENO_VACIO;
									juego->isengard[j].fila = fila+1;
								}
							}
							if(juego->terreno[ULTIMA_FILA][col] == ORCO){
								juego->terreno[ULTIMA_FILA][col] = TERRENO_VACIO;
								(juego->llegadas_isengard)++;
							}
						}
					}
				}
		}
}
void inicializar_juego(juego_t* juego){
	juego->uruk.codigo = URUK;
	juego->elfos.codigo = ELFO; 
	juego->hombres.codigo = HOMBRE; 
	juego->orcos.codigo = ORCO;  
	juego->cantidad_isengard = 0;
	juego->cantidad_rohan = 0;
	juego->turno_rohan = true;
	juego->turno_isengard = true;
	juego->llegadas_rohan = 0;
	juego->llegadas_isengard = 0;
	srand((unsigned)time(NULL));
	
	cargar_mapa_inicial(juego->terreno);
	printf("Completar Datos para el JUGADOR 1.\n\n");	
	perfil(&(juego)->j1.tipo, &(juego)->j1.intensidad);
	if(juego->j1.tipo == ROHAN){
		juego->j2.tipo = ISENGARD;
	}else{
		juego->j2.tipo = ROHAN;
	}
	juego->j2.intensidad = INTENSIDAD_MAX - juego->j1.intensidad;
	
	plus(juego->j1, juego);
	plus(juego->j2, juego);
	
	juego->j1.energia = ENERGIA_INICIAL;
	juego->j2.energia = ENERGIA_INICIAL;
	
	
	printf("1-Jugador vs. CPU\n2-Jugador 1 vs. Jugador 2\n");
	scanf("%i",&(juego->cant_jugadores));
	
	system("clear");
	inicializar_personajes_fijos(&(juego)->elfos, juego);
	inicializar_personajes_movibles(&(juego)->hombres, juego);
	inicializar_personajes_fijos(&(juego)->uruk, juego);
	inicializar_personajes_movibles(&(juego)->orcos, juego);	
	posicionar_uruk_aleatorio(juego, juego->uruk);
	posicionar_elfo_aleatorio(juego, juego->elfos);
}
void posicionar_personaje(juego_t* juego, personaje_t personaje){
	if(personaje.codigo == HOMBRE){
		posicionar_hombre(juego, juego->hombres);
	}
	if(personaje.codigo == ORCO){
		posicionar_orco(juego, juego->orcos);
	}
	if(personaje.codigo == ELFO){
		posicionar_elfo(juego, juego->elfos);
	}
	if(personaje.codigo == URUK){
		posicionar_uruk(juego, juego->uruk);
	}
}
void jugar(juego_t* juego, char bando, int posicion_personaje){
	if(bando == ISENGARD){
		movimiento_orcos(juego, ISENGARD, juego->isengard->fila);
	}else{
		movimiento_hombres(juego, ROHAN, juego->rohan->fila);
	}
}