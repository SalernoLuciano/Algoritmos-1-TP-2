#ifndef __BATALLA_H__
#define __BATALLA_H__
#include "perfil.h"
#include <stdbool.h>

#define MAX_TERRENO_FIL 10
#define MAX_TERRENO_COL 10
#define PRIMER_FILA 0
#define ULTIMA_FILA 9
#define PRIMER_COLUMNA 0
#define ULTIMA_COLUMNA 9
#define MAX_PERSONAJES 200
#define PERSONAJES_INICIALES 3

#define ENERGIA_INICIAL 5
#define ENERGIA_MAX 10
#define VIDA_HOMBRE_ORCO 100
#define VIDA_ELFO_URUK 200
#define PTS_HOMBRE_ORCO 3
#define PTS_ELFO_URUK 8
#define ATAQUE_HOMBRE_ORCO 50
#define ATAQUE_ELFO_URUK 10
#define HOMBRE 'H'
#define ORCO 'O'
#define ELFO 'E'
#define URUK 'U'
#define TERRENO_VACIO '-'
#define RANGO_PLUS 6
#define LLEGADAS_GANAR 5

typedef struct personaje {
	char codigo;
	int vida;
	int ataque;
	int fila;
	int columna;
	// Pueden agregar los campos que deseen
	int pts_energia;
} personaje_t;

typedef struct juego {
	char terreno[MAX_TERRENO_FIL][MAX_TERRENO_COL];
	personaje_t rohan[MAX_PERSONAJES];
	int cantidad_rohan;
	int llegadas_rohan;
	int plus_rohan;
	personaje_t isengard[MAX_PERSONAJES];
	int cantidad_isengard;
	int llegadas_isengard;
	int plus_isengard;
	// Pueden agregar los campos que deseen
	personaje_t uruk;
	personaje_t elfos;
	personaje_t hombres;
	personaje_t orcos;
	jugador_t j1;
	jugador_t j2;
	bool turno_rohan;
	char rta_rohan;
	int crear_rohan;
	int fila_rohan;
	int col_rohan;
	bool turno_isengard;
	char rta_isengard;
	int crear_isengard;
	int fila_isengard;
	int col_isengard;
	int cant_jugadores;
} juego_t;
/*
 *Pre:pasa una matriz vacia que representara al terreno.
 *Post: guarda una interfaz grafica basica para representar la matriz como un terreno por pantalla.
 */
void cargar_mapa_inicial(char terreno[MAX_TERRENO_FIL][MAX_TERRENO_COL]);

/*
 *Pre: Tomo la intensidad(del 1 al 10)de un jugador.
 *Post: devuelve un plus para calcular la vida y el ataque de los personajes de cada jugador.
 */
void plus(jugador_t jugador, juego_t* juego);

/*
 *Pre: el personaje pasado debe ser Elfo o Uruk-Hai y de juego se utilizara el campo plus.
 *Post: deja inicializados correctamente los campos vida, ataque y puntos de energia que cuesta crear los personajes Elfos y Uruk-Hai.
 */
void inicializar_personajes_fijos(personaje_t* personaje, juego_t* juego);

/*
 *Pre: el personaje pasado debe ser Hombre u Orco y se utilizara de juego el campo plus
 *Post: deja inicializados correctamente los campos de los personajes Hombres y Orcos.
 */
void inicializar_personajes_movibles(personaje_t* personaje, juego_t* juego);

/*
 *Pre: se le tiene que pasar un personaje que sea Uruk-Hai.
 *Post: Deja cargado en el terreno un Uruk-Hai en una posicion aleatoria valida.
 */
void posicionar_uruk_aleatorio( juego_t* juego, personaje_t uruk);


/*
 *Pre: se le tiene que pasar un personaje que sea Elfo.
 *Post: Deja cargado en el terreno un elfo en una posicion aleatoria valida.
 */
void posicionar_elfo_aleatorio( juego_t* juego, personaje_t elfos);


/*
 *Post: muestra por pantall el terreno de juego actualizado.
 */
void actualizar_terreno(char terreno[MAX_TERRENO_FIL][MAX_TERRENO_COL]);

/*
 *Pre: Se le debe pasar el personaje de tipo Hombre.
 *Post:Se posicionara un personaje hombre en el terreno correspondiente (en la ultima fila) con todos sus campos asignados correctamente y se restara la energia correspondiente a crear un hombre al jugador correspondiente.
 */
void posicionar_hombre(juego_t* juego, personaje_t personaje);

/*
 *Pre: Se le debe pasar el personaje de tipo Orco.
 *Post:Se posicionara un personaje Orco en el terreno correspondiente(en la primer fila) con todos sus campos asignados correctamente y se restara la energia correspondiente a crear un Orco al jugador correspondiente.
 */
void posicionar_orco(juego_t* juego, personaje_t personaje);

/*
 *Pre: Se le debe pasar el personaje de tipo Elfo.
 *Post:Se posicionara un personaje Elfo en el terreno correspondiente (fila y columna del campo de Rohan) con todos sus campos asignados correctamente y se restara la energia correspondiente a crear un Elfo al jugador correspondiente.
 */
void posicionar_elfo(juego_t* juego, personaje_t personaje);

/*
 *Pre: Se le debe pasar el personaje de tipo Uruk-Hai.
 *Post:Se posicionara un personaje Uruk-Hai en el terreno correspondiente (fila y columna del campo de Isengard) con todos sus campos asignados correctamente y se restara la energia correspondiente a crear un Uruk-Hai al jugador correspondiente.
 */
void posicionar_uruk(juego_t* juego, personaje_t personaje);

/*
 * Inicializará todos los valores del juego, dejándolo en un estado 
 * inicial válido.
 */
void inicializar_juego(juego_t* juego);

/*
 * Recibirá un personaje, con todos sus campos correctamente cargados y
 * lo dará de alta en el juego, sumándolo al vector correspondiente,
 * posicionándolo también en la matriz.
 */
void posicionar_personaje(juego_t* juego, personaje_t personaje);

/*
 * Realizará la jugada del personaje del bando recibido que
 * se encuentra en la posición posicion_personaje.
 * Se moverá o atacará dependiento lo que corresponda.
 * Actualizará el juego según los efectos del movimiento del
 * personaje, matar rivales, actualizar la matriz, restar vida, etc.
 */
void jugar(juego_t* juego, char bando, int posicion_personaje);

#endif /* __BATALLA_H__ */