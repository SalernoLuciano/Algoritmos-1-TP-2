#include <stdio.h>
#include "batalla.h"
#include "perfil.h"
#include <time.h>
#include <stdlib.h> 
void validar_respuesta_crear(char* rta){
	while((*rta) != 'S' && (*rta) != 's' && (*rta) !='N' && (*rta) !='n'){
		printf("ERROR. No es una respuesta valida. Si quiere crear un personaje insgre 'S' o 's'\nEn caso contrario ingrese 'N' o 'n'.\n");
		scanf(" %c", rta);
	}
}
void cargar_mapa_inicial(char terreno[MAX_TERRENO_FIL][MAX_TERRENO_COL]){
	for(int fila = PRIMER_FILA; fila<MAX_TERRENO_FIL; fila++){
		for(int columna = PRIMER_COLUMNA; columna<MAX_TERRENO_COL; columna++){
			terreno[fila][columna] = TERRENO_VACIO;
		}
	}
}
void actualizar_terreno(juego_t* juego){
	for(int fila = PRIMER_FILA; fila < MAX_TERRENO_FIL; fila++){
		for(int col = PRIMER_COLUMNA; col<MAX_TERRENO_COL; col++){
			for(int i=0; i< juego->cantidad_isengard; i++){
				if(fila == juego->isengard[i].fila && col == juego->isengard[i].columna){
					juego->terreno[fila][col]=juego->isengard[i].codigo;
				}
			}
			for(int r=0; r<juego->cantidad_rohan; r++){
				if(fila == juego->rohan[r].fila && col == juego->rohan[r].columna){
					juego->terreno[fila][col]=juego->rohan[r].codigo;
				}
			}
			printf(" %c\t",juego->terreno[fila][col]);
		}
		printf("\n");
	}
	printf("\n");
}
void plus(jugador_t jugador, juego_t* juego){
	if(jugador.tipo == ROHAN){
		juego->plus_rohan = jugador.intensidad * (rand()%RANGO_PLUS);
	}else{
		juego->plus_isengard = jugador.intensidad * (rand()%RANGO_PLUS);
	}
}
void inicializar_personajes_fijos(personaje_t* personaje, int plus){
	if(personaje->codigo == URUK){
		personaje->vida = VIDA_ELFO_URUK - plus;
		personaje->ataque = ATAQUE_ELFO_URUK + plus;
		personaje->pts_energia = PTS_ELFO_URUK;
	}else{
		personaje->vida = VIDA_ELFO_URUK - plus;
		personaje->ataque = ATAQUE_ELFO_URUK + plus;
		personaje->pts_energia = PTS_ELFO_URUK;
	}
}
void inicializar_personajes_movibles(personaje_t* personaje, int plus){
	if(personaje->codigo == ORCO){
		personaje->vida = VIDA_HOMBRE_ORCO - plus;
		personaje->ataque = ATAQUE_HOMBRE_ORCO + plus;
		personaje->pts_energia = PTS_HOMBRE_ORCO;
	}else{
		personaje->vida = VIDA_HOMBRE_ORCO - plus;
		personaje->ataque = ATAQUE_HOMBRE_ORCO + plus;
		personaje->pts_energia = PTS_HOMBRE_ORCO;
	}
}
void posicionar_uruk_aleatorio( int* cantidad_isengard, personaje_t uruk, char terreno[MAX_TERRENO_FIL][MAX_TERRENO_COL], personaje_t isengard[MAX_PERSONAJES]){
	int fil_rndm;
	int col_rndm;
		for(; (*cantidad_isengard)<PERSONAJES_INICIALES; (*cantidad_isengard)++){
			fil_rndm = (rand()%4)+1;
			col_rndm = rand()%10;
			for(int i=0; i<(*cantidad_isengard); i++){
				while(isengard[i].fila == fil_rndm && isengard[i].columna == col_rndm){
					fil_rndm = (rand()%4)+1;
					col_rndm = rand()%10;
				}
			}
			isengard[(*cantidad_isengard)].codigo = uruk.codigo;
			isengard[(*cantidad_isengard)].vida = uruk.vida;
			isengard[(*cantidad_isengard)].ataque = uruk.ataque;
			isengard[(*cantidad_isengard)].fila = fil_rndm;
			isengard[(*cantidad_isengard)].columna = col_rndm;
			isengard[(*cantidad_isengard)].pts_energia = uruk.pts_energia;
		}
}
void posicionar_elfo_aleatorio( int* cantidad_rohan, personaje_t elfos, char terreno[MAX_TERRENO_FIL][MAX_TERRENO_COL], personaje_t rohan[MAX_PERSONAJES]){
	int fil_rndm;
	int col_rndm;
		for(; (*cantidad_rohan)<PERSONAJES_INICIALES; (*cantidad_rohan)++){
			fil_rndm = (rand()%4)+5;
			col_rndm = rand()%10;
			for(int i=0; i<(*cantidad_rohan); i++){
				while(rohan[i].fila == fil_rndm && rohan[i].columna == col_rndm){
					fil_rndm = (rand()%4)+5;
					col_rndm = rand()%10;
				}
			}
			rohan[(*cantidad_rohan)].codigo = elfos.codigo;
			rohan[(*cantidad_rohan)].vida = elfos.vida;
			rohan[(*cantidad_rohan)].ataque = elfos.ataque;
			rohan[(*cantidad_rohan)].fila = fil_rndm;
			rohan[(*cantidad_rohan)].columna = col_rndm;
			rohan[(*cantidad_rohan)].pts_energia = elfos.pts_energia;
		}
}
void posicionar_hombre_aleatorio( int* cantidad_rohan, personaje_t hombres, char terreno[MAX_TERRENO_FIL][MAX_TERRENO_COL], personaje_t rohan[MAX_PERSONAJES], jugador_t* j1, jugador_t* j2){
	int col_rndm;
	col_rndm = rand()%10;
	while((terreno[ULTIMA_FILA][col_rndm])!=TERRENO_VACIO){
		col_rndm = rand()%10;
	}
	rohan[(*cantidad_rohan)].codigo = hombres.codigo;
	rohan[(*cantidad_rohan)].vida = hombres.vida;
	rohan[(*cantidad_rohan)].ataque = hombres.ataque;
	rohan[(*cantidad_rohan)].fila = ULTIMA_FILA;
	rohan[(*cantidad_rohan)].columna = col_rndm;
	rohan[(*cantidad_rohan)].pts_energia = hombres.pts_energia;
	(*cantidad_rohan)++;
	if((*j1).tipo == ROHAN){
		(*j1).energia -= hombres.pts_energia;
	}else{
		(*j2).energia -= hombres.pts_energia;
	}
}
void posicionar_orco_aleatorio( int* cantidad_isengard, personaje_t orcos, char terreno[MAX_TERRENO_FIL][MAX_TERRENO_COL], personaje_t isengard[MAX_PERSONAJES], jugador_t* j1, jugador_t* j2){
	int col_rndm;
	col_rndm = rand()%10;
	while((terreno[PRIMER_FILA][col_rndm])!=TERRENO_VACIO){
		col_rndm = rand()%10;
	}
	isengard[(*cantidad_isengard)].codigo = orcos.codigo;
	isengard[(*cantidad_isengard)].vida = orcos.vida;
	isengard[(*cantidad_isengard)].ataque = orcos.ataque;
	isengard[(*cantidad_isengard)].fila = PRIMER_FILA;
	isengard[(*cantidad_isengard)].columna = col_rndm;
	isengard[(*cantidad_isengard)].pts_energia = orcos.pts_energia;
	(*cantidad_isengard)++;
	if((*j1).tipo == ISENGARD){
		(*j1).energia -= orcos.pts_energia;
	}else{
		(*j2).energia -= orcos.pts_energia;
	}
}
void posicionar_hombre(juego_t* juego, personaje_t personaje){
	printf("Elija una columna (del 0 al 9) de la ultima fila donde quiera posicionar al Hombre.\n");
	scanf("%i", &(juego->col_rohan));
	while((juego->col_rohan>ULTIMA_COLUMNA) || (juego->col_rohan)<PRIMER_COLUMNA){
		printf("ERROR: el numero no es valido.\nElija una columna (del 0 al 9) de la ultima fila donde quiera posicionar al hombre.\n");
		scanf("%i", &(juego->col_rohan));
	}
	while(juego->terreno[ULTIMA_FILA][juego->col_rohan]!= TERRENO_VACIO){
		printf("ERROR: Ese espacio esta ocupado.\nElija una columna (del 0 al 9) de la ultima fila donde quiera posicionar al hombre.\n");
		scanf("%i", &(juego->col_rohan));
	}
	juego->rohan[juego->cantidad_rohan].codigo = HOMBRE;
	juego->rohan[juego->cantidad_rohan].vida = personaje.vida;
	juego->rohan[juego->cantidad_rohan].ataque = personaje.ataque;
	juego->rohan[juego->cantidad_rohan].fila = ULTIMA_FILA;
	juego->rohan[juego->cantidad_rohan].columna = juego->col_rohan;
	juego->rohan[juego->cantidad_rohan].pts_energia = PTS_HOMBRE_ORCO;
	juego->cantidad_rohan++;
	if(juego->j1.tipo == ROHAN){
		juego->j1.energia -= personaje.pts_energia;
	}else{
		juego->j2.energia -= personaje.pts_energia;
	}
}
void posicionar_orco(juego_t* juego, personaje_t personaje){
	printf("Elija una columna (del 0 al 9) de la primer fila donde quiera posicionar al Orco.\n");
	scanf("%i", &(juego->col_isengard));
	while((juego->col_isengard>ULTIMA_COLUMNA) || (juego->col_isengard)<PRIMER_COLUMNA){
		printf("ERROR: el numero no es valido.\nElija una columna (del 0 al 9) de la primer fila donde quiera posicionar al Orco.\n");
		scanf("%i", &(juego->col_isengard));
	}
	while(juego->terreno[PRIMER_FILA][juego->col_isengard]!= TERRENO_VACIO){
		printf("ERROR: Ese espacio esta ocupado.\nElija una columna (del 0 al 9) de la primer fila donde quiera posicionar al Orco.\n");
		scanf("%i", &(juego->col_isengard));
	}
	juego->isengard[juego->cantidad_isengard].codigo = ORCO;
	juego->isengard[juego->cantidad_isengard].vida = personaje.vida;
	juego->isengard[juego->cantidad_isengard].ataque = personaje.ataque;
	juego->isengard[juego->cantidad_isengard].fila = PRIMER_FILA;
	juego->isengard[juego->cantidad_isengard].columna = juego->col_isengard;
	juego->isengard[juego->cantidad_isengard].pts_energia = PTS_HOMBRE_ORCO;
	(juego->cantidad_isengard)++;
	if(juego->j1.tipo == ISENGARD){
		juego->j1.energia -= personaje.pts_energia;
	}else{
		juego->j2.energia -= personaje.pts_energia;
	}
}
void posicionar_elfo(juego_t* juego, personaje_t personaje){
	printf("Elija una fila de su mitad de terreno donde quiera ubicar a su Elfo.\n");
	scanf("%i", &(juego->fila_rohan));
	while((juego->fila_rohan<((ULTIMA_FILA/2)+1)) || (juego->fila_rohan)>(ULTIMA_FILA-1)){
		printf("ERROR: el numero no es valido.\nElija una fila (del 5 al 8) donde quiera posicionar al Elfo.\n");
		scanf("%i", &(juego->fila_rohan));
	}
	printf("Elija una columna donde quiera ubicar a su Elfo.\n");
	scanf("%i", &(juego->col_rohan));
	while((juego->col_rohan < PRIMER_COLUMNA) || (juego->col_rohan) > ULTIMA_COLUMNA){
		printf("ERROR: el numero no es valido.\nElija una columna (del 0 al 9) donde quiera posicionar al Elfo.\n");
		scanf("%i", &(juego->col_rohan));
	}
	while(juego->terreno[juego->fila_rohan][juego->col_rohan]!= TERRENO_VACIO){
		printf("ERROR: Ese espacio esta ocupado.\nElija una fila (del 5 al 8) donde quiera posicionar al Elfo.\n");
		scanf("%i", &(juego->fila_rohan));
		while((juego->fila_rohan<((ULTIMA_FILA/2)+1)) || (juego->fila_rohan)>(ULTIMA_FILA-1)){
			printf("ERROR: el numero no es valido.\nElija una fila (del 5 al 8) donde quiera posicionar al Elfo.\n");
			scanf("%i", &(juego->fila_rohan));
		}
		printf("ERROR: Ese espacio esta ocupado.\nElija una columna (del 0 al 9) donde quiera posicionar al Elfo.\n");
		scanf("%i", &(juego->col_rohan));
		while((juego->col_rohan < PRIMER_COLUMNA) || (juego->col_rohan) > ULTIMA_COLUMNA){
			printf("ERROR: el numero no es valido.\nElija una columna (del 0 al 9) donde quiera posicionar al Elfo.\n");
			scanf("%i", &(juego->col_rohan));
		}
	}
	juego->rohan[juego->cantidad_rohan].codigo = ELFO;
	juego->rohan[juego->cantidad_rohan].vida = personaje.vida;
	juego->rohan[juego->cantidad_rohan].ataque = personaje.ataque;
	juego->rohan[juego->cantidad_rohan].fila = juego->fila_rohan;
	juego->rohan[juego->cantidad_rohan].columna = juego->col_rohan;
	juego->rohan[juego->cantidad_rohan].pts_energia = PTS_ELFO_URUK;
	(juego->cantidad_rohan)++;
	if(juego->j1.tipo == ROHAN){
		juego->j1.energia -= personaje.pts_energia;
	}else{
		juego->j2.energia -= personaje.pts_energia;
	}
}
void posicionar_uruk(juego_t* juego, personaje_t personaje){
	printf("Elija una fila de su mitad de terreno donde quiera ubicar a su Uruk-Hai.\n");
	scanf("%i", &(juego->fila_isengard));
	while((juego->fila_isengard<(PRIMER_FILA+1)) || (juego->fila_isengard)>(ULTIMA_FILA/2)){
		printf("ERROR: el numero no es valido.\nElija una fila (del 1 al 4) donde quiera posicionar al Uruk-Hai.\n");
		scanf("%i", &(juego->fila_isengard));
	}
	printf("Elija una columna donde quiera ubicar a su Uruk-Hai.\n");
	scanf("%i", &(juego->col_isengard));
	while((juego->col_isengard < PRIMER_COLUMNA) || (juego->col_isengard) > ULTIMA_COLUMNA){
		printf("ERROR: el numero no es valido.\nElija una columna (del 0 al 9) donde quiera posicionar al Uruk-Hai.\n");
		scanf("%i", &(juego->col_isengard));
	}
	while(juego->terreno[juego->fila_isengard][juego->col_isengard]!= TERRENO_VACIO){
		printf("ERROR: Ese espacio esta ocupado.\nElija una fila (del 1 al 4) donde quiera posicionar al Uruk-Hai.\n");
		scanf("%i", &(juego->fila_isengard));
		while((juego->fila_isengard < (PRIMER_FILA+1)) || (juego->fila_isengard) > (ULTIMA_FILA/2)){
			printf("ERROR: el numero no es valido.\nElija una fila (del 1 al 4) donde quiera posicionar al Uruk-Hai.\n");
			scanf("%i", &(juego->fila_isengard));
		}
		printf("ERROR: Ese espacio esta ocupado.\nElija una columna (del 0 al 9) donde quiera posicionar al Uruk-Hai.\n");
		scanf("%i", &(juego->col_isengard));
		while((juego->col_isengard < PRIMER_COLUMNA) || (juego->col_isengard) > ULTIMA_COLUMNA){
			printf("ERROR: el numero no es valido.\nElija una columna (del 0 al 9) donde quiera posicionar al Uruk-Hai.\n");
			scanf("%i", &(juego->col_isengard));
		}
	}
	juego->isengard[juego->cantidad_isengard].codigo = URUK;
	juego->isengard[juego->cantidad_isengard].vida = personaje.vida;
	juego->isengard[juego->cantidad_isengard].ataque = personaje.ataque;
	juego->isengard[juego->cantidad_isengard].fila = juego->fila_isengard;
	juego->isengard[juego->cantidad_isengard].columna = juego->col_isengard;
	juego->isengard[juego->cantidad_isengard].pts_energia = PTS_ELFO_URUK;
	(juego->cantidad_isengard)++;
	if(juego->j1.tipo == ISENGARD){
		juego->j1.energia -= personaje.pts_energia;
	}else{
		juego->j2.energia -= personaje.pts_energia;
	}
}
void eliminar_personaje(int* cantidad, personaje_t personaje[MAX_PERSONAJES], int* llegadas){
	for(int i=0; i<(*cantidad); i++){
		if(personaje[i].vida == 0){
			for(int j=i+1; j<(*cantidad); j++){
				personaje[i] = personaje[j];	
			}
			(*cantidad)--;
		}else if(personaje[i].codigo == HOMBRE && personaje[i].fila == PRIMER_FILA && personaje[i].vida > 0){
			(*llegadas)++;
			for(int j=i+1; j<(*cantidad); j++){
				personaje[i] = personaje[j];	
			}
			(*cantidad)--;
		}else if(personaje[i].codigo == ORCO && personaje[i].fila == ULTIMA_FILA && personaje[i].vida > 0){
			(*llegadas)++;
			for(int j=i+1; j<(*cantidad); j++){
				personaje[i] = personaje[j];	
			}
			(*cantidad)--;
		}
	}		
}
void movimiento_hombres(juego_t* juego, char bando, int posicion_personaje){
	for(int i=0; i<juego->cantidad_rohan;i++){
		if(juego->rohan[i].codigo == HOMBRE){	
			if(juego->terreno[juego->rohan[i].fila-1][juego->rohan[i].columna] == TERRENO_VACIO || juego->terreno[juego->rohan[i].fila-1][juego->rohan[i].columna] == ELFO){
				juego->rohan[i].fila -=1;
			}
		}
	}
	for(int i=0; i<juego->cantidad_rohan; i++){
		if(juego->rohan[i].fila == PRIMER_FILA){
			eliminar_personaje(&(juego)->cantidad_rohan, juego->rohan, &(juego)->llegadas_rohan);
		}
	}
}
void movimiento_orcos(juego_t* juego, char bando, int posicion_personaje){
	for(int i=0; i<juego->cantidad_isengard;i++){
		if(juego->isengard[i].codigo == ORCO){	
			if(juego->terreno[juego->isengard[i].fila+1][juego->isengard[i].columna] == TERRENO_VACIO || juego->terreno[juego->isengard[i].fila+1][juego->isengard[i].columna] == URUK){
				juego->isengard[i].fila +=1;
			}
		}
	}
	for(int i=0; i<juego->cantidad_isengard; i++){
		if(juego->isengard[i].fila == ULTIMA_FILA){
			eliminar_personaje(&(juego)->cantidad_isengard, juego->isengard, &(juego)->llegadas_isengard);
		}
	}
}
void inicializar_juego(juego_t* juego){
	juego->uruk.codigo = URUK;
	juego->elfos.codigo = ELFO; 
	juego->hombres.codigo = HOMBRE; 
	juego->orcos.codigo = ORCO;  
	juego->cantidad_isengard = 0;
	juego->cantidad_rohan = 0;
	juego->turno_rohan = true;
	juego->turno_isengard = true;
	juego->llegadas_rohan = 0;
	juego->llegadas_isengard = 0;
	srand((unsigned)time(NULL));
	
	cargar_mapa_inicial(juego->terreno);
	printf("Completar Datos para el JUGADOR 1.\n\n");	
	perfil(&(juego)->j1.tipo, &(juego)->j1.intensidad);
	if(juego->j1.tipo == ROHAN){
		juego->j2.tipo = ISENGARD;
	}else{
		juego->j2.tipo = ROHAN;
	}
	juego->j2.intensidad = INTENSIDAD_MAX - juego->j1.intensidad;
	
	plus(juego->j1, juego);
	plus(juego->j2, juego);
	
	juego->j1.energia = ENERGIA_INICIAL;
	juego->j2.energia = ENERGIA_INICIAL;
	
	
	printf("1-Jugador vs. CPU\n2-Jugador 1 vs. Jugador 2\n");
	scanf("%i",&(juego->cant_jugadores));
	
	system("clear");
	inicializar_personajes_fijos(&(juego)->elfos, juego->plus_rohan);
	inicializar_personajes_movibles(&(juego)->hombres, juego->plus_rohan);
	inicializar_personajes_fijos(&(juego)->uruk, juego->plus_isengard);
	inicializar_personajes_movibles(&(juego)->orcos, juego->plus_isengard);	
	posicionar_uruk_aleatorio(&(juego)->cantidad_isengard, juego->uruk, juego->terreno, juego->isengard);
	posicionar_elfo_aleatorio(&(juego)->cantidad_rohan, juego->elfos, juego->terreno, juego->rohan);
}
void posicionar_personaje(juego_t* juego, personaje_t personaje){
	if(personaje.codigo == HOMBRE){
		posicionar_hombre(juego, juego->hombres);
	}
	if(personaje.codigo == ORCO){
		posicionar_orco(juego, juego->orcos);
	}
	if(personaje.codigo == ELFO){
		posicionar_elfo(juego, juego->elfos);
	}
	if(personaje.codigo == URUK){
		posicionar_uruk(juego, juego->uruk);
	}
}
void ataque_hombres(juego_t* juego){
	for(int i=0; i<juego->cantidad_rohan; i++){
		if(juego->rohan[i].codigo == HOMBRE && juego->rohan[i].vida > 0){
			for(int r=0; r<juego->cantidad_isengard;r++){
				if((abs(juego->rohan[i].fila - juego->isengard[r].fila) + abs(juego->rohan[i].columna - juego->isengard[r].columna))<=1 && juego->isengard[r].vida > 0){
					juego->isengard[r].vida-=juego->rohan[i].ataque;
					if(juego->isengard[r].vida<=0){
						juego->terreno[juego->isengard[r].fila][juego->isengard[r].columna]=TERRENO_VACIO;
						juego->isengard[r].vida = 0;
					}
				}else if((juego->rohan[i].fila)-1 == juego->isengard[r].fila && (juego->rohan[i].columna)-1 == juego->isengard[r].columna && ((juego->rohan[i].fila)-1 >= PRIMER_FILA) && ((juego->rohan[i].columna)-1 >= PRIMER_COLUMNA)){
					juego->isengard[r].vida-=juego->rohan[i].ataque;
					if(juego->isengard[r].vida<=0){
						juego->terreno[juego->isengard[r].fila][juego->isengard[r].columna]=TERRENO_VACIO;
						juego->isengard[r].vida = 0;
					}
				}else if((juego->rohan[i].fila)-1 == juego->isengard[r].fila && (juego->rohan[i].columna)+1 == juego->isengard[r].columna && ((juego->rohan[i].fila)-1 >= PRIMER_FILA) && ((juego->rohan[i].columna)+1 <= ULTIMA_COLUMNA)){
					juego->isengard[r].vida-=juego->rohan[i].ataque;
					if(juego->isengard[r].vida<=0){
						juego->terreno[juego->isengard[r].fila][juego->isengard[r].columna]=TERRENO_VACIO;
						juego->isengard[r].vida = 0;
					}
				}else if((juego->rohan[i].fila)+1 == juego->isengard[r].fila && (juego->rohan[i].columna)-1 == juego->isengard[r].columna && ((juego->rohan[i].fila)+1 <= ULTIMA_FILA) && ((juego->rohan[i].columna)-1 >= PRIMER_COLUMNA)){
					juego->isengard[r].vida-=juego->rohan[i].ataque;
					if(juego->isengard[r].vida<=0){
						juego->terreno[juego->isengard[r].fila][juego->isengard[r].columna]=TERRENO_VACIO;
						juego->isengard[r].vida = 0;
					}
				}else if((juego->rohan[i].fila)+1 == juego->isengard[r].fila && (juego->rohan[i].columna)+1 == juego->isengard[r].columna && ((juego->rohan[i].fila)+1 <= ULTIMA_FILA) && ((juego->rohan[i].columna)+1 <= ULTIMA_COLUMNA)){
					juego->isengard[r].vida-=juego->rohan[i].ataque;
					if(juego->isengard[r].vida<=0){
						juego->terreno[juego->isengard[r].fila][juego->isengard[r].columna]=TERRENO_VACIO;
						juego->isengard[r].vida = 0;
					}
				}
			}
		}	
	}

	for(int i=0; i<juego->cantidad_isengard; i++){
		if(juego->isengard[i].vida == 0){
			eliminar_personaje(&(juego)->cantidad_isengard, juego->isengard, &(juego)->llegadas_isengard);
		}
	}
}
void ataque_orcos(juego_t* juego){
	for(int i=0; i<juego->cantidad_isengard; i++){
		if(juego->isengard[i].codigo == ORCO && juego->isengard[i].vida > 0){
			for(int r=0; r<juego->cantidad_rohan;r++){
				if((abs(juego->isengard[i].fila - juego->rohan[r].fila) + abs(juego->isengard[i].columna - juego->rohan[r].columna))<=1 && juego->rohan[r].vida > 0){
					juego->rohan[r].vida-=juego->isengard[i].ataque;
					if(juego->rohan[r].vida<=0){
						juego->terreno[juego->rohan[r].fila][juego->rohan[r].columna]=TERRENO_VACIO;
						juego->rohan[r].vida = 0;
					}
				}else if((juego->isengard[i].fila)-1 == juego->rohan[r].fila && (juego->isengard[i].columna)-1 == juego->rohan[r].columna && ((juego->isengard[i].fila)-1 >= PRIMER_FILA) && ((juego->isengard[i].columna)-1 >= PRIMER_COLUMNA)){
					juego->rohan[r].vida-=juego->isengard[i].ataque;
					if(juego->rohan[r].vida<=0){
						juego->terreno[juego->rohan[r].fila][juego->rohan[r].columna]=TERRENO_VACIO;
						juego->rohan[r].vida = 0;
					}
				}else if((juego->isengard[i].fila)-1 == juego->rohan[r].fila && (juego->isengard[i].columna)+1 == juego->rohan[r].columna && ((juego->isengard[i].fila)-1 >= PRIMER_FILA) && ((juego->isengard[i].columna)+1 <= ULTIMA_COLUMNA)){
					juego->rohan[r].vida-=juego->isengard[i].ataque;
					if(juego->rohan[r].vida<=0){
						juego->terreno[juego->rohan[r].fila][juego->rohan[r].columna]=TERRENO_VACIO;
						juego->rohan[r].vida = 0;
					}
				}else if((juego->isengard[i].fila)+1 == juego->rohan[r].fila && (juego->isengard[i].columna)-1 == juego->rohan[r].columna && ((juego->isengard[i].fila)+1 <= ULTIMA_FILA) && ((juego->isengard[i].columna)-1 >= PRIMER_COLUMNA)){
					juego->rohan[r].vida-=juego->isengard[i].ataque;
					if(juego->rohan[r].vida<=0){
						juego->terreno[juego->rohan[r].fila][juego->rohan[r].columna]=TERRENO_VACIO;
						juego->rohan[r].vida = 0;
					}
				}else if((juego->isengard[i].fila)+1 == juego->rohan[r].fila && (juego->isengard[i].columna)+1 == juego->rohan[r].columna && ((juego->isengard[i].fila)+1 <= ULTIMA_FILA) && ((juego->isengard[i].columna)+1 <= ULTIMA_COLUMNA)){
					juego->rohan[r].vida-=juego->isengard[i].ataque;
					if(juego->rohan[r].vida<=0){
						juego->terreno[juego->rohan[r].fila][juego->rohan[r].columna]=TERRENO_VACIO;
						juego->rohan[r].vida = 0;
					}
				}
			}
		}	
	}
	for(int i=0; i<juego->cantidad_rohan; i++){
		if(juego->rohan[i].vida == 0){
			eliminar_personaje(&(juego)->cantidad_rohan, juego->rohan, &(juego)->llegadas_rohan);
		}
	}
}
void ataque_elfos(juego_t* juego){
	for(int i=0; i<juego->cantidad_rohan; i++){
		if(juego->rohan[i].codigo == ELFO && juego->rohan[i].vida > 0){
			for(int r=0; r<juego->cantidad_isengard;r++){
				if((abs(juego->rohan[i].fila - juego->isengard[r].fila)+ abs(juego->rohan[i].columna - juego->isengard[r].columna))<=3 && juego->isengard[r].vida > 0){
					juego->isengard[r].vida-=juego->rohan[i].ataque;
					if(juego->isengard[r].vida<=0){
						juego->isengard[r].vida = 0;
					}
				}
			}
		}
	}
	eliminar_personaje(&(juego)->cantidad_isengard, juego->isengard, &(juego)->llegadas_isengard);				
}
void ataque_uruk(juego_t* juego){
	for(int i=0; i<juego->cantidad_isengard; i++){
		if(juego->isengard[i].codigo == URUK && juego->isengard[i].vida > 0){
			for(int r=0; r<juego->cantidad_rohan;r++){
				if((abs(juego->isengard[i].fila - juego->rohan[r].fila) + abs(juego->isengard[i].columna - juego->rohan[r].columna))<= 3 && juego->rohan[r].vida > 0){
					juego->rohan[r].vida-=juego->isengard[i].ataque;
					if(juego->rohan[r].vida<=0){
						juego->terreno[juego->rohan[r].fila][juego->rohan[r].columna]=TERRENO_VACIO;
						juego->rohan[r].vida = 0;
					}
				}
			}
		}
	}
	eliminar_personaje(&(juego)->cantidad_rohan, juego->rohan, &(juego)->llegadas_rohan);
}
void jugar(juego_t* juego, char bando, int posicion_personaje){
	if(bando == ISENGARD){
		movimiento_orcos(juego, ISENGARD, juego->isengard->fila);
		ataque_orcos(juego);
		ataque_uruk(juego);

	}else{
		movimiento_hombres(juego, ROHAN, juego->rohan->fila);
		ataque_hombres(juego);
		ataque_elfos(juego);
	}
}