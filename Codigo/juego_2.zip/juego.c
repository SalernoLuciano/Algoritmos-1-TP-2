#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "perfil.h"
#include "batalla.h"

int main(){
	juego_t juego;
	bool juego_terminado = false;
	bool turno_rohan = true;
	bool turno_isengard = true;

	inicializar_juego(&juego);
	printf("Jugador 1: %c\n", juego.j1.tipo);
	printf("Jugador 2: %c\n", juego.j2.tipo);
	if(juego.cant_jugadores == 2){
		while(juego_terminado == false){
			while(turno_rohan){
				system("clear");
				if(juego.j1.tipo == ROHAN){
					/*for(int i=0; i<juego.cantidad_rohan; i++){
						printf("\nBando ROHAN:\n----------\nPersonaje %i.\n-----\nVida: %i\nfila: %i.\nColumna: %i.\nAtaque: %i.\n----------\n",i+1, juego.rohan[i].vida, juego.rohan[i].fila, juego.rohan[i].columna, juego.rohan[i].ataque);
					}*/
					cargar_mapa_inicial(juego.terreno);
					actualizar_terreno(&juego);
					/*for(int j=0; j<juego.cantidad_isengard; j++){
						printf("\nBando ISENGARD:\n----------\nPersonaje %i.\n-----\nVida: %i\nfila: %i.\nColumna: %i.\nAtaque: %i.\n----------\n",j+1, juego.isengard[j].vida, juego.isengard[j].fila, juego.isengard[j].columna, juego.isengard[j].ataque);
					}*/
					printf("Energia Rohan: %i\n", juego.j1.energia);
					printf("Llegadas Rohan: %i", juego.llegadas_rohan);
					printf("\n\t\tTURNO ROHAN.\nDesea crear un personaje?.(S/N).\n");
					scanf(" %c", &(juego.rta_rohan));
					validar_respuesta_crear(&(juego).rta_rohan);
					if(juego.rta_rohan == 'S' || juego.rta_rohan == 's'){
						printf("Que personaje desea crear?.\n1-Hombre.(3pts. de energia)\n2-Elfo.(8pts. de energia)\n");
						scanf("%i", &(juego.crear_rohan));
						while(juego.crear_rohan !=1 && juego.crear_rohan !=2){
							printf("ERROR. Ingrese una opcion valida.\n1-Hombre.(3pts. de energia)\n2-Elfo.(8pts. de energia)\n");
							scanf("%i", &(juego.crear_rohan));
						}
						if(juego.crear_rohan == 1){
							if(juego.j1.energia >= juego.hombres.pts_energia){
								posicionar_personaje(&juego, juego.hombres);
							}else{
							printf("\nNo tiene puntos suficientes para crear a un Hombre.\n");
							}
						}else{
							if(juego.j1.energia >= juego.elfos.pts_energia){
								posicionar_personaje(&juego, juego.elfos);
							}else{
								printf("\nNo tiene puntos suficientes para crear a un Elfo.\n");
							}
						}
					}else{
						turno_rohan = false;
						turno_isengard = true;
					}
				}else if(juego.j2.tipo == ROHAN){
					/*for(int i=0; i<juego.cantidad_rohan; i++){
						printf("\nBando ROHAN:\n----------\nPersonaje %i.\n-----\nVida: %i\nfila: %i.\nColumna: %i.\nAtaque: %i.\n----------\n",i+1, juego.rohan[i].vida, juego.rohan[i].fila, juego.rohan[i].columna, juego.rohan[i].ataque);
					}*/
					cargar_mapa_inicial(juego.terreno);
					actualizar_terreno(&juego);
					/*for(int j=0; j<juego.cantidad_isengard; j++){
						printf("\nBando ISENGARD:\n----------\nPersonaje %i.\n-----\nVida: %i\nfila: %i.\nColumna: %i.\nAtaque: %i.\n----------\n",j+1, juego.isengard[j].vida, juego.isengard[j].fila, juego.isengard[j].columna, juego.isengard[j].ataque);
					}*/
					printf("Energia Rohan: %i\n", juego.j2.energia);
					printf("Llegadas Rohan: %i", juego.llegadas_rohan);
					printf("\n\t\tTURNO ROHAN.\nDesea crear un personaje?.(S/N).\n");
					scanf(" %c", &(juego.rta_rohan));
					validar_respuesta_crear(&(juego).rta_rohan);
					if(juego.rta_rohan == 'S' || juego.rta_rohan == 's'){
						printf("Que personaje desea crear?.\n1-Hombre.(3pts. de energia)\n2-Elfo.(8pts. de energia)\n");
						scanf("%i", &(juego.crear_rohan));
						while(juego.crear_rohan !=1 && juego.crear_rohan !=2){
							printf("ERROR. Ingrese una opcion valida.\n1-Hombre.(3pts. de energia)\n2-Elfo.(8pts. de energia)\n");
							scanf("%i", &(juego.crear_rohan));
						}
						if(juego.crear_rohan == 1){
							if(juego.j2.energia >= juego.hombres.pts_energia){
								posicionar_personaje(&juego, juego.hombres);
							}else{
								printf("No tiene puntos suficientes para crear a un Hombre.\n");
							}
						}else{
							if(juego.j2.energia >= juego.elfos.pts_energia){
								posicionar_personaje(&juego, juego.elfos);
							}else{
								printf("No tiene puntos suficientes para crear a un Elfo.\n");
							}
						}
					}else{
						turno_rohan = false;
						turno_isengard = true;
					}
				}
			}
			jugar(&juego, ROHAN, juego.rohan->fila);
			if(juego.llegadas_rohan == LLEGADAS_GANAR){
				juego_terminado = true;
				turno_isengard=false;
				turno_rohan = false;
				system("clear");
				printf("\n\n\nRohan Gana!!!\n");
			}
			while(turno_isengard){
				system("clear");
				if(juego.j1.tipo == ISENGARD){
					/*for(int i=0; i<juego.cantidad_rohan; i++){
						printf("\nBando ROHAN:\n----------\nPersonaje %i.\n-----\nVida: %i\nfila: %i.\nColumna: %i.\nAtaque: %i.\n----------\n",i+1, juego.rohan[i].vida, juego.rohan[i].fila, juego.rohan[i].columna, juego.rohan[i].ataque);
					}*/
					cargar_mapa_inicial(juego.terreno);
					actualizar_terreno(&juego);
					/*for(int j=0; j<juego.cantidad_isengard; j++){
						printf("\nBando ISENGARD:\n----------\nPersonaje %i.\n-----\nVida: %i\nfila: %i.\nColumna: %i.\nAtaque: %i.\n----------\n",j+1, juego.isengard[j].vida, juego.isengard[j].fila, juego.isengard[j].columna, juego.isengard[j].ataque);
					}*/
					printf("Energia Isengard: %i\n", juego.j1.energia);
					printf("Llegadas Isengard: %i", juego.llegadas_isengard);
					printf("\n\t\tTURNO ISENGARD.\nDesea crear un personaje?.(S/N).\n");
					scanf(" %c", &(juego.rta_isengard));
					if(juego.rta_isengard == 'S' || juego.rta_isengard == 's'){
						printf("Que personaje desea crear?.\n1-Orco.(3pts. de energia)\n2-Uruk-Hai.(8pts. de energia)\n");
						scanf("%i", &(juego.crear_isengard));
						validar_respuesta_crear(&(juego).rta_isengard);
						while(juego.crear_isengard !=1 && juego.crear_isengard !=2){
							printf("ERROR. Ingrese una opcion valida.\n1-Orco.(3pts. de energia)\n2-Uruk-Hai.(8pts. de energia)\n");
							scanf("%i", &(juego.crear_isengard));
						}
						if(juego.crear_isengard == 1){
							if(juego.j1.energia >= juego.orcos.pts_energia){
								posicionar_personaje(&juego, juego.orcos);
							}else{
								printf("No tiene puntos suficientes para crear a un Orco.\n");
							}
						}else{
							if(juego.j1.energia >= juego.uruk.pts_energia){
								posicionar_personaje(&juego, juego.uruk);
							}else{
								printf("No tiene puntos suficientes para crear a un Uruk-Hai.\n");
							}
						}
					}else{
						turno_isengard = false;
						turno_rohan = true;
					}
				}else if(juego.j2.tipo == ISENGARD){
					/*for(int i=0; i<juego.cantidad_rohan; i++){
						printf("\nBando ROHAN:\n----------\nPersonaje %i.\n-----\nVida: %i\nfila: %i.\nColumna: %i.\nAtaque: %i.\n----------\n",i+1, juego.rohan[i].vida, juego.rohan[i].fila, juego.rohan[i].columna, juego.rohan[i].ataque);
					}*/
					cargar_mapa_inicial(juego.terreno);
					actualizar_terreno(&juego);
					/*for(int j=0; j<juego.cantidad_isengard; j++){
						printf("\nBando ISENGARD:\n----------\nPersonaje %i.\n-----\nVida: %i\nfila: %i.\nColumna: %i.\nAtaque: %i.\n----------\n",j+1, juego.isengard[j].vida, juego.isengard[j].fila, juego.isengard[j].columna, juego.isengard[j].ataque);
					}*/	
					printf("Energia Isengard: %i\n", juego.j2.energia);
					printf("Llegadas Isengard: %i", juego.llegadas_isengard);
					printf("\n\t\tTURNO ISENGARD.\nDesea crear un personaje?.(S/N).\n");
					scanf(" %c", &(juego.rta_isengard));
					validar_respuesta_crear(&(juego).rta_isengard);
					if(juego.rta_isengard == 'S' || juego.rta_isengard == 's'){
						printf("Que personaje desea crear?.\n1-Orco.(3pts. de energia)\n2-Uruk-Hai.(8pts. de energia)\n");
						scanf("%i", &(juego.crear_isengard));
						while(juego.crear_isengard !=1 && juego.crear_isengard !=2){
							printf("ERROR. Ingrese una opcion valida.\n1-Orco.(3pts. de energia)\n2-Uruk-Hai.(8pts. de energia)\n");
							scanf("%i", &(juego.crear_isengard));
						}
						if(juego.crear_isengard == 1){
							if(juego.j2.energia >= juego.orcos.pts_energia){
								posicionar_personaje(&juego, juego.orcos);
							}else{
								printf("No tiene puntos suficientes para crear a un Orco.\n");
							}
						}else{
							if(juego.j2.energia >= juego.uruk.pts_energia){
								posicionar_personaje(&juego, juego.uruk);
							}else{
								printf("No tiene puntos suficientes para crear a un Uruk-Hai.\n");
							}
						}
					}else{
						turno_isengard = false;
						turno_rohan = true;
					}		
				}	
			}
			jugar(&juego, ISENGARD, juego.isengard->fila);
			if(juego.llegadas_isengard == LLEGADAS_GANAR){
				juego_terminado = true;
				turno_isengard=false;
				turno_rohan = false;
				system("clear");
				printf("\n\n\nIsengard. Gana!!!\n");
			}							
			juego.j1.energia++;
			juego.j2.energia++;
			if(juego.j1.energia > ENERGIA_MAX){
				juego.j1.energia = ENERGIA_MAX;
			}
			if(juego.j2.energia > ENERGIA_MAX){
				juego.j2.energia = ENERGIA_MAX;
			}		
		}
	}else if(juego.cant_jugadores == 1){
		while(juego_terminado == false){
			while(turno_rohan){
				system("clear");
				if(juego.j1.tipo == ROHAN){
					/*for(int i=0; i<juego.cantidad_rohan; i++){
						printf("\nBando ROHAN:\n----------\nPersonaje %i.\n-----\nVida: %i\nfila: %i.\nColumna: %i.\nAtaque: %i.\n----------\n",i+1, juego.rohan[i].vida, juego.rohan[i].fila, juego.rohan[i].columna, juego.rohan[i].ataque);
					}*/
					cargar_mapa_inicial(juego.terreno);
					actualizar_terreno(&juego);
					/*for(int j=0; j<juego.cantidad_isengard; j++){
						printf("\nBando ISENGARD:\n----------\nPersonaje %i.\n-----\nVida: %i\nfila: %i.\nColumna: %i.\nAtaque: %i.\n----------\n",j+1, juego.isengard[j].vida, juego.isengard[j].fila, juego.isengard[j].columna, juego.isengard[j].ataque);
					}*/
					printf("Energia Rohan: %i\n", juego.j1.energia);
					printf("Llegadas Rohan: %i", juego.llegadas_rohan);
					printf("\n\t\tTURNO ROHAN.\nDesea crear un personaje?.(S/N).\n");
					scanf(" %c", &(juego.rta_rohan));
					validar_respuesta_crear(&(juego).rta_rohan);
					if(juego.rta_rohan == 'S' || juego.rta_rohan == 's'){
						printf("Que personaje desea crear?.\n1-Hombre.(3pts. de energia)\n2-Elfo.(8pts. de energia)\n");
						scanf("%i", &(juego.crear_rohan));
						while(juego.crear_rohan !=1 && juego.crear_rohan !=2){
							printf("ERROR. Ingrese una opcion valida.\n1-Hombre.(3pts. de energia)\n2-Elfo.(8pts. de energia)\n");
							scanf("%i", &(juego.crear_rohan));
						}
						if(juego.crear_rohan == 1){
							if(juego.j1.energia >= juego.hombres.pts_energia){
								posicionar_personaje(&juego, juego.hombres);
							}else{
							printf("\nNo tiene puntos suficientes para crear a un Hombre.\n");
							}
						}else{
							if(juego.j1.energia >= juego.elfos.pts_energia){
								posicionar_personaje(&juego, juego.elfos);
							}else{
								printf("\nNo tiene puntos suficientes para crear a un Elfo.\n");
							}
						}
					}else{
						turno_rohan = false;
						turno_isengard = true;
					}
				}else if(juego.j2.tipo == ROHAN){
					/*for(int i=0; i<juego.cantidad_rohan; i++){
						printf("\nBando ROHAN:\n----------\nPersonaje %i.\n-----\nVida: %i\nfila: %i.\nColumna: %i.\nAtaque: %i.\n----------\n",i+1, juego.rohan[i].vida, juego.rohan[i].fila, juego.rohan[i].columna, juego.rohan[i].ataque);
					}*/
					cargar_mapa_inicial(juego.terreno);
					actualizar_terreno(&juego);
					/*for(int j=0; j<juego.cantidad_isengard; j++){
						printf("\nBando ISENGARD:\n----------\nPersonaje %i.\n-----\nVida: %i\nfila: %i.\nColumna: %i.\nAtaque: %i.\n----------\n",j+1, juego.isengard[j].vida, juego.isengard[j].fila, juego.isengard[j].columna, juego.isengard[j].ataque);
					}*/
					printf("\nEnergia Rohan: %i\n", juego.j2.energia);
					printf("\nLlegadas Rohan: %i\n", juego.llegadas_rohan);
					printf("\n\t\tTURNO ROHAN.\n");					
					if(juego.j2.energia >= juego.hombres.pts_energia){
						posicionar_hombre_aleatorio(&(juego).cantidad_rohan, juego.hombres, juego.terreno,  juego.rohan, &(juego).j1, &(juego).j2);
					}else{
						printf("\nNo tiene puntos suficientes para crear a un Hombre.\n");
					}
					turno_isengard = true;
					turno_rohan = false;
				}
			}
			jugar(&juego, ROHAN, juego.rohan->fila);
			if(juego.llegadas_rohan == LLEGADAS_GANAR){
				juego_terminado = true;
				turno_isengard=false;
				turno_rohan = false;
				system("clear");
				printf("\n\n\nRohan Gana!!!\n");
			}
			while(turno_isengard){
				system("clear");	
				if(juego.j1.tipo == ISENGARD){
					/*for(int i=0; i<juego.cantidad_rohan; i++){
						printf("\nBando ROHAN:\n----------\nPersonaje %i.\n-----\nVida: %i\nfila: %i.\nColumna: %i.\nAtaque: %i.\n----------\n",i+1, juego.rohan[i].vida, juego.rohan[i].fila, juego.rohan[i].columna, juego.rohan[i].ataque);
					}*/
					cargar_mapa_inicial(juego.terreno);
					actualizar_terreno(&juego);
					/*for(int j=0; j<juego.cantidad_isengard; j++){
						printf("\nBando ISENGARD:\n----------\nPersonaje %i.\n-----\nVida: %i\nfila: %i.\nColumna: %i.\nAtaque: %i.\n----------\n",j+1, juego.isengard[j].vida, juego.isengard[j].fila, juego.isengard[j].columna, juego.isengard[j].ataque);
					}*/
					printf("\nEnergia Isengard: %i\n", juego.j1.energia);
					printf("\nLlegadas Isengard: %i\n", juego.llegadas_isengard);
					printf("\n\t\tTURNO ISENGARD.\nDesea crear un personaje?.(S/N).\n");
					scanf(" %c", &(juego.rta_isengard));
					if(juego.rta_isengard == 'S' || juego.rta_isengard == 's'){
						printf("\nQue personaje desea crear?.\n1-Orco.(3pts. de energia)\n2-Uruk-Hai.(8pts. de energia)\n");
						scanf("%i", &(juego.crear_isengard));
						validar_respuesta_crear(&(juego).rta_isengard);
						while(juego.crear_isengard !=1 && juego.crear_isengard !=2){
							printf("\nERROR. Ingrese una opcion valida.\n1-Orco.(3pts. de energia)\n2-Uruk-Hai.(8pts. de energia)\n");
							scanf("%i", &(juego.crear_isengard));
						}
						if(juego.crear_isengard == 1){
							if(juego.j1.energia >= juego.orcos.pts_energia){
								posicionar_personaje(&juego, juego.orcos);
							}else{
								printf("\nNo tiene puntos suficientes para crear a un Orco.\n");
							}
						}else{
							if(juego.j1.energia >= juego.uruk.pts_energia){
								posicionar_personaje(&juego, juego.uruk);
							}else{
								printf("\nNo tiene puntos suficientes para crear a un Uruk-Hai.\n");
							}
						}
					}else{
						turno_isengard = false;
						turno_rohan = true;
					}
				}else if(juego.j2.tipo == ISENGARD){
					/*for(int i=0; i<juego.cantidad_rohan; i++){
						printf("\nBando ROHAN:\n----------\nPersonaje %i.\n-----\nVida: %i\nfila: %i.\nColumna: %i.\nAtaque: %i.\n----------\n",i+1, juego.rohan[i].vida, juego.rohan[i].fila, juego.rohan[i].columna, juego.rohan[i].ataque);
					}*/
					cargar_mapa_inicial(juego.terreno);
					actualizar_terreno(&juego);
					/*for(int j=0; j<juego.cantidad_isengard; j++){
						printf("\nBando ISENGARD:\n----------\nPersonaje %i.\n-----\nVida: %i\nfila: %i.\nColumna: %i.\nAtaque: %i.\n----------\n",j+1, juego.isengard[j].vida, juego.isengard[j].fila, juego.isengard[j].columna, juego.isengard[j].ataque);
					}*/
					printf("\nEnergia Isengard: %i\n", juego.j2.energia);
					printf("\nLlegadas Isengard: %i\n", juego.llegadas_isengard);
					printf("\n\t\tTURNO ISENGARD.\n");					
					if(juego.j2.energia >= juego.orcos.pts_energia){
						posicionar_orco_aleatorio(&(juego).cantidad_isengard, juego.orcos, juego.terreno,  juego.isengard, &(juego).j1, &(juego).j2);
					}else{
						printf("\nNo tiene puntos suficientes para crear a un Orco.\n");
					}
					turno_isengard = false;
					turno_rohan = true;
				}
			}
			jugar(&juego, ISENGARD, juego.isengard->fila);
			if(juego.llegadas_isengard == LLEGADAS_GANAR){
				juego_terminado = true;
				turno_isengard=false;
				turno_rohan = false;
				system("clear");
				printf("\n\n\nIsengard. Gana!!!\n");
			}							
			juego.j1.energia++;
			juego.j2.energia++;
			if(juego.j1.energia > ENERGIA_MAX){
				juego.j1.energia = ENERGIA_MAX;
			}
			if(juego.j2.energia > ENERGIA_MAX){
				juego.j2.energia = ENERGIA_MAX;
			}
		}
	}
	return 0;
} 