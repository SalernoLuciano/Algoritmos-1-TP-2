#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "perfil.h"
#include "batalla.h"
#include <string.h>

int main(){
	juego_t juego;
	bool juego_terminado = false;
	bool turno_rohan = true;
	bool turno_isengard = true;
	char nombre_rohan[20] = "Rohan";
	char nombre_isengard[20] = "Isengard";

	inicializar_juego(&juego);
	printf("Jugador 1: %c\n", juego.j1.tipo);
	printf("Jugador 2: %c\n", juego.j2.tipo);
	if(juego.cant_jugadores == 2){
		while(juego_terminado == false){
			//turno_roh(&turno_rohan, &turno_isengard, &juego, &juego_terminado, nombre_rohan);
			//turno_isen(&turno_rohan, &turno_isengard, &juego, &juego_terminado, nombre_isengard);
			turno(&turno_rohan, ROHAN, &juego, nombre_rohan, &(juego).llegadas_rohan, "Hombre", "Elfo", juego.hombres, juego.elfos, &turno_isengard, juego.rohan, &juego_terminado);
			turno(&turno_isengard, ISENGARD, &juego, nombre_isengard, &(juego).llegadas_isengard, "Orco", "Uruk-Hai", juego.orcos, juego.uruk, &turno_rohan, juego.isengard, &juego_terminado);
			aumentar_energia(&(juego).j1, &(juego).j2);				
		}
	}else if(juego.cant_jugadores == 1){
		while(juego_terminado == false){
			while(turno_rohan){
				system("clear");
				if(juego.j1.tipo == ROHAN){
					cargar_mapa_inicial(juego.terreno);
					cargar_personajes(&juego);
					actualizar_terreno(&juego);
					printf("Energia Rohan: %i\n", juego.j1.energia);
					printf("Llegadas Rohan: %i", juego.llegadas_rohan);
					printf("\n\t\tTURNO ROHAN.\nDesea crear un personaje?.(S/N).\n");
					scanf(" %c", &(juego.rta_rohan));
					validar_respuesta_crear(&(juego).rta_rohan);
					if(juego.rta_rohan == 'S' || juego.rta_rohan == 's'){
						printf("Que personaje desea crear?.\n1-Hombre.(3pts. de energia)\n2-Elfo.(8pts. de energia)\n");
						scanf("%i", &(juego.crear_rohan));
						while(juego.crear_rohan !=1 && juego.crear_rohan !=2){
							printf("ERROR. Ingrese una opcion valida.\n1-Hombre.(3pts. de energia)\n2-Elfo.(8pts. de energia)\n");
							scanf("%i", &(juego.crear_rohan));
						}
						if(juego.crear_rohan == 1){
							if(juego.j1.energia >= juego.hombres.pts_energia){
								posicionar_personaje(&juego, juego.hombres);
								juego.j1.energia -= juego.hombres.pts_energia;
							}else{
							printf("\nNo tiene puntos suficientes para crear a un Hombre.\n");
							}
						}else{
							if(juego.j1.energia >= juego.elfos.pts_energia){
								posicionar_personaje(&juego, juego.elfos);
								juego.j1.energia -= juego.elfos.pts_energia;
							}else{
								printf("\nNo tiene puntos suficientes para crear a un Elfo.\n");
							}
						}
					}else{
						turno_rohan = false;
						turno_isengard = true;
					}
				}else if(juego.j2.tipo == ROHAN){
					cargar_mapa_inicial(juego.terreno);
					cargar_personajes(&juego);
					actualizar_terreno(&juego);
					printf("\nEnergia Rohan: %i\n", juego.j2.energia);
					printf("\nLlegadas Rohan: %i\n", juego.llegadas_rohan);
					printf("\n\t\tTURNO ROHAN.\n");					
					if(juego.j2.energia >= juego.hombres.pts_energia){
						posicionar_movil_aleatorio(&(juego).cantidad_rohan, juego.hombres, juego.terreno,  juego.rohan, &(juego).j2, ULTIMA_FILA);
					}else{
						printf("\nNo tiene puntos suficientes para crear a un Hombre.\n");
					}
					turno_isengard = true;
					turno_rohan = false;
				}
			}
			jugar(&juego, ROHAN, juego.rohan->fila);
			ganar(juego.llegadas_rohan, &juego_terminado, &turno_rohan, &turno_isengard, nombre_rohan);
			while(turno_isengard){
				system("clear");	
				if(juego.j1.tipo == ISENGARD){
					cargar_mapa_inicial(juego.terreno);
					cargar_personajes(&juego);
					actualizar_terreno(&juego);
					printf("\nEnergia Isengard: %i\n", juego.j1.energia);
					printf("\nLlegadas Isengard: %i\n", juego.llegadas_isengard);
					printf("\n\t\tTURNO ISENGARD.\nDesea crear un personaje?.(S/N).\n");
					scanf(" %c", &(juego.rta_isengard));
					if(juego.rta_isengard == 'S' || juego.rta_isengard == 's'){
						printf("\nQue personaje desea crear?.\n1-Orco.(3pts. de energia)\n2-Uruk-Hai.(8pts. de energia)\n");
						scanf("%i", &(juego.crear_isengard));
						validar_respuesta_crear(&(juego).rta_isengard);
						while(juego.crear_isengard !=1 && juego.crear_isengard !=2){
							printf("\nERROR. Ingrese una opcion valida.\n1-Orco.(3pts. de energia)\n2-Uruk-Hai.(8pts. de energia)\n");
							scanf("%i", &(juego.crear_isengard));
						}
						if(juego.crear_isengard == 1){
							if(juego.j1.energia >= juego.orcos.pts_energia){
								posicionar_personaje(&juego, juego.orcos);
							}else{
								printf("\nNo tiene puntos suficientes para crear a un Orco.\n");
							}
						}else{
							if(juego.j1.energia >= juego.uruk.pts_energia){
								posicionar_personaje(&juego, juego.uruk);
								juego.j1.energia -= juego.uruk.pts_energia; 
							}else{
								printf("\nNo tiene puntos suficientes para crear a un Uruk-Hai.\n");
							}
						}
					}else{
						turno_isengard = false;
						turno_rohan = true;
					}
				}else if(juego.j2.tipo == ISENGARD){
					cargar_mapa_inicial(juego.terreno);
					cargar_personajes(&juego);
					actualizar_terreno(&juego);
					printf("\nEnergia Isengard: %i\n", juego.j2.energia);
					printf("\nLlegadas Isengard: %i\n", juego.llegadas_isengard);
					printf("\n\t\tTURNO ISENGARD.\n");					
					if(juego.j2.energia >= juego.orcos.pts_energia){
						posicionar_movil_aleatorio(&(juego).cantidad_isengard, juego.orcos, juego.terreno,  juego.isengard, &(juego).j2, PRIMER_FILA);
					}else{
						printf("\nNo tiene puntos suficientes para crear a un Orco.\n");
					}
					turno_isengard = false;
					turno_rohan = true;
				}
			}
			jugar(&juego, ISENGARD, juego.isengard->fila);
			ganar(juego.llegadas_isengard, &juego_terminado, &turno_isengard, &turno_rohan, nombre_isengard);		
			aumentar_energia(&(juego).j1, &(juego).j2);
		}
	}
	return 0;
} 